
import React from 'react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { formatCurrency, formatNumber } from '../../utils';

const mockData = Array.from({ length: 30 }, (_, i) => ({
  date: `Oct ${i + 1}`,
  gmv: 50000 + Math.random() * 30000,
  fees: 2000 + Math.random() * 1000,
}));

const DailyGMVChart: React.FC = () => {
  return (
    <div className="glass rounded-2xl p-6 border border-brand-border/40 min-w-0 flex flex-col h-full">
      <div className="flex justify-between items-start mb-8">
        <div>
          <h3 className="text-lg font-bold text-white tracking-tight">Daily GMV & Fees</h3>
          <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest mt-1">30-Day Aggregated Revenue Stream</p>
        </div>
        <select className="bg-brand-navy border border-brand-border text-[10px] font-bold text-gray-400 rounded px-3 py-1.5 outline-none focus:border-gold transition-colors cursor-pointer">
          <option>Last 30 Days</option>
          <option>Last 90 Days</option>
          <option>Year to Date</option>
        </select>
      </div>

      {/* Stable container for Recharts with explicit height to prevent sizing warnings */}
      <div className="w-full h-[320px] min-h-[320px] flex items-center justify-center relative">
        <ResponsiveContainer width="99.9%" height="100%">
          <AreaChart data={mockData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
            <defs>
              <linearGradient id="colorGmv" x1="0" y1="0" x2="0" y2="1">
                <stop offset="5%" stopColor="#0EA5E9" stopOpacity={0.2}/>
                <stop offset="95%" stopColor="#0EA5E9" stopOpacity={0}/>
              </linearGradient>
            </defs>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#1E3A5F" />
            <XAxis 
              dataKey="date" 
              stroke="#2D4A6F" 
              fontSize={9} 
              tickLine={false} 
              axisLine={false} 
              tick={{ fill: '#718096' }}
              interval={4}
            />
            <YAxis 
              stroke="#2D4A6F" 
              fontSize={9} 
              tickLine={false} 
              axisLine={false} 
              tick={{ fill: '#718096' }}
              tickFormatter={(val) => `$${formatNumber(val)}`}
            />
            <Tooltip 
              contentStyle={{ background: '#0D1B2A', border: '1px solid #2D4A6F', borderRadius: '12px', boxShadow: '0 20px 25px -5px rgba(0,0,0,0.5)' }} 
              itemStyle={{ color: '#D4A853', fontWeight: 'bold', fontSize: '11px' }} 
              labelStyle={{ color: '#718096', marginBottom: '4px', fontSize: '10px', fontWeight: 'bold' }}
              formatter={(value: number) => [formatCurrency(value), 'GMV']}
            />
            <Area 
              type="monotone" 
              dataKey="gmv" 
              stroke="#D4A853" 
              strokeWidth={2} 
              fillOpacity={1} 
              fill="url(#colorGmv)" 
              animationDuration={1500}
            />
          </AreaChart>
        </ResponsiveContainer>
      </div>

      <div className="grid grid-cols-2 gap-4 mt-8 pt-6 border-t border-brand-border/40">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">Total Bids</span>
            <span className="text-[9px] font-black text-success">+21.7%</span>
          </div>
          <p className="text-xl font-mono font-bold text-white">$66.3K</p>
          <p className="text-[9px] text-gray-600 font-bold uppercase mt-1">Institutional liquidity index</p>
        </div>
        <div className="text-right">
          <div className="flex items-center justify-end gap-2 mb-1">
            <span className="text-[9px] font-black text-teal">Performance →</span>
            <span className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">Transaction Fees</span>
          </div>
          <p className="text-xl font-mono font-bold text-gold">$124K</p>
          <p className="text-[9px] text-gray-600 font-bold uppercase mt-1">Net platform capture</p>
        </div>
      </div>
    </div>
  );
};

export default DailyGMVChart;
