
import React from 'react';
import { cn, formatCurrency } from '../../utils';

const SupplierStats: React.FC = () => {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      <div className="glass p-6 rounded-2xl border border-brand-border/40 relative overflow-hidden group">
        <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
          <span className="material-icons text-5xl text-white">description</span>
        </div>
        <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-2">RFQs Received</p>
        <div className="flex items-baseline gap-3 mb-4">
          <h3 className="text-3xl font-mono font-bold text-white">50</h3>
          <div className="text-[10px] font-black text-success uppercase flex items-center gap-1">
            <span className="material-icons text-xs">north</span>
            +17%
          </div>
        </div>
        <div className="flex items-center justify-between p-2 rounded bg-white/5 border border-white/5">
          <span className="text-[9px] font-bold text-gray-500 uppercase">Conversion Rate</span>
          <span className="text-[10px] font-bold text-teal uppercase">2116 Inv (40%)</span>
        </div>
      </div>

      <div className="glass p-6 rounded-2xl border border-brand-border/40 relative overflow-hidden group">
        <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
          <span className="material-icons text-5xl text-white">gavel</span>
        </div>
        <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-2">Active Auctions</p>
        <div className="flex items-baseline gap-3 mb-4">
          <h3 className="text-3xl font-mono font-bold text-white">7</h3>
          <div className="text-[10px] font-black text-error uppercase flex items-center gap-1">
            <span className="material-icons text-xs">south</span>
            -8.74%
          </div>
        </div>
        <div className="flex items-center justify-between p-2 rounded bg-white/5 border border-white/5">
          <span className="text-[9px] font-bold text-gray-500 uppercase">Avg. Bid Delta</span>
          <span className="text-[10px] font-bold text-gold uppercase">+$1.2k Spot</span>
        </div>
      </div>

      <div className="glass p-6 rounded-2xl border border-brand-border/40 relative overflow-hidden group">
        <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
          <span className="material-icons text-5xl text-white">monetization_on</span>
        </div>
        <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-2">Price Requested</p>
        <div className="flex items-baseline gap-3 mb-4">
          <h3 className="text-3xl font-mono font-bold text-white">{formatCurrency(3750000)}</h3>
          <div className="text-[10px] font-black text-success uppercase flex items-center gap-1">
            <span className="material-icons text-xs">north</span>
            +3.3%
          </div>
        </div>
        <div className="flex items-center justify-between p-2 rounded bg-white/5 border border-white/5">
          <span className="text-[9px] font-bold text-gray-500 uppercase">YTD Target</span>
          <span className="text-[10px] font-bold text-white uppercase">75% Complete</span>
        </div>
      </div>
    </div>
  );
};

export default SupplierStats;
