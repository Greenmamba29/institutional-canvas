
import React from 'react';
import { formatNumber } from '../../utils';

const MissionControl: React.FC = () => {
  return (
    <div className="p-4 border-t border-brand-border">
      <div className="glass-premium p-4 rounded-xl relative overflow-hidden group">
        <div className="absolute top-0 right-0 w-16 h-16 bg-gold/5 blur-xl rounded-full translate-x-1/2 -translate-y-1/2"></div>
        
        <div className="space-y-4 relative z-10">
          {/* GMV Metric */}
          <div>
            <div className="flex justify-between items-center mb-1">
              <span className="text-[9px] font-bold text-gray-500 uppercase tracking-[0.15em]">GMV (YTD)</span>
              <div className="flex items-center gap-1 text-[9px] font-bold text-success">
                <span className="material-icons text-[10px]">north</span>
                12.4%
              </div>
            </div>
            <div className="text-lg font-mono font-bold text-white">$15.2M</div>
          </div>

          {/* Supplier/Buyer Counts */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <span className="text-[8px] font-bold text-gray-500 uppercase tracking-widest block mb-0.5">Suppliers</span>
              <span className="text-xs font-bold text-white">147 <span className="text-[8px] text-gold font-bold">VERIFIED</span></span>
            </div>
            <div>
              <span className="text-[8px] font-bold text-gray-500 uppercase tracking-widest block mb-0.5">Buyers</span>
              <span className="text-xs font-bold text-white">17,402 <span className="text-[8px] text-teal font-bold">VERIFIED</span></span>
            </div>
          </div>

          {/* Micro Sparkline (SVG) */}
          <div className="h-8 w-full">
            <svg viewBox="0 0 100 20" className="w-full h-full overflow-visible">
              <path 
                d="M0 15 L10 12 L20 18 L30 10 L40 14 L50 6 L60 8 L70 2 L80 10 L90 4 L100 0" 
                fill="none" 
                stroke="#D4A853" 
                strokeWidth="1.5"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="drop-shadow-[0_0_3px_rgba(212,168,83,0.5)]"
              />
            </svg>
          </div>
        </div>
      </div>
      
      <div className="mt-4 px-2 flex items-center justify-between text-[8px] font-bold text-gray-600 uppercase tracking-widest">
        <span>Mission Control Center</span>
        <span className="text-teal animate-pulse">● Connected</span>
      </div>
    </div>
  );
};

export default MissionControl;
