
import React from 'react';
import { cn, formatCurrency } from '../../utils';

const MetricsReview: React.FC = () => {
  const tableData = [
    { desc: 'Li-Hydroxide LCE', remainder: '4.2k', gain: '+1.2%' },
    { desc: 'Carbonate Batch A', remainder: '1.8k', gain: '-0.4%' },
    { desc: 'Spodumene Conc.', remainder: '12.4k', gain: '+5.6%' },
    { desc: 'Chloride Purified', remainder: '0.9k', gain: '+0.1%' },
  ];

  return (
    <div className="glass rounded-2xl p-6 border border-brand-border/40 h-full">
      <div className="flex justify-between items-center mb-6">
        <h3 className="text-xs font-black text-white uppercase tracking-[0.2em]">Metrics Review</h3>
        <span className="material-icons text-gray-600 text-sm">more_vert</span>
      </div>

      <div className="flex items-center gap-4 mb-8">
        <div className="text-4xl font-mono font-bold text-white tracking-tighter">$04.27M</div>
        <div className="bg-success/10 border border-success/30 px-2 py-1 rounded">
          <span className="text-[10px] font-black text-success uppercase tracking-tighter">+6.3K TODAY</span>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4 mb-8">
        {[
          { label: 'Gross Merchandise Value', val: '52.1M', sub: 'Institutional' },
          { label: 'Stacked Data', val: '52 Firm', sub: 'Verified' },
          { label: 'Verification Media', val: '17 Vers', sub: 'Gold Tier' },
        ].map((item, i) => (
          <div key={i} className="flex justify-between items-center py-2 border-b border-brand-border/20 last:border-0">
            <div>
              <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">{item.label}</p>
              <p className="text-[9px] text-gray-600 font-bold uppercase">{item.sub}</p>
            </div>
            <p className="text-sm font-mono font-bold text-white">{item.val}</p>
          </div>
        ))}
      </div>

      <div className="mb-8">
        <div className="flex justify-between items-center mb-4">
          <h4 className="text-[10px] font-black text-teal uppercase tracking-widest">GMV Escrowed</h4>
          <select className="bg-transparent text-[9px] font-bold text-gray-500 outline-none cursor-pointer uppercase">
            <option>All Assets</option>
          </select>
        </div>
        
        <table className="w-full">
          <thead>
            <tr className="text-left">
              <th className="text-[8px] font-black text-gray-600 uppercase pb-2">Description</th>
              <th className="text-[8px] font-black text-gray-600 uppercase pb-2 text-right">Remainder</th>
              <th className="text-[8px] font-black text-gray-600 uppercase pb-2 text-right">Gain</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-brand-border/10">
            {tableData.map((row, i) => (
              <tr key={i}>
                <td className="py-2 text-[11px] font-medium text-gray-400">{row.desc}</td>
                <td className="py-2 text-[11px] font-mono font-bold text-white text-right">{row.remainder}</td>
                <td className={cn(
                  "py-2 text-[10px] font-black text-right",
                  row.gain.startsWith('+') ? "text-success" : "text-error"
                )}>
                  {row.gain}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="p-4 rounded-xl bg-brand-panel/30 border border-brand-border/30">
        <div className="flex justify-between items-center">
          <div>
            <p className="text-[9px] font-bold text-gray-500 uppercase tracking-widest mb-1">Platform Fees Earned</p>
            <p className="text-lg font-mono font-bold text-gold">{formatCurrency(124800)}</p>
          </div>
          <div className="w-12 h-12 rounded-full border border-teal/20 flex items-center justify-center">
            <span className="material-icons text-teal text-xl">payments</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MetricsReview;
