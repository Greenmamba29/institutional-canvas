
import React from 'react';
import { cn } from '../../utils';

type LogType = 'approved' | 'cancelled' | 'flagged';

interface LogEntry {
  id: string;
  type: LogType;
  title: string;
  subtitle: string;
  timestamp: string;
  actionLabel: string;
}

const logs: LogEntry[] = [
  {
    id: '1',
    type: 'approved',
    title: 'Approved Santiago Lithium S.A.',
    subtitle: 'KYB verification Tier 1 passed',
    timestamp: '12m ago',
    actionLabel: 'Review Escrow'
  },
  {
    id: '2',
    type: 'cancelled',
    title: 'Escrow Contract Cancelled',
    subtitle: 'Order #77421 - Buyer withdrawal',
    timestamp: '2h ago',
    actionLabel: 'Escrow Details'
  },
  {
    id: '3',
    type: 'flagged',
    title: 'Flagged CleanTech Ventures',
    subtitle: 'Purity mismatch reported by auditor',
    timestamp: '5m ago',
    actionLabel: 'Review'
  },
  {
    id: '4',
    type: 'approved',
    title: 'Withdrawal Approved',
    subtitle: 'Batch ID: B990212001MT',
    timestamp: '6h ago',
    actionLabel: 'Settlement'
  }
];

const AuditLog: React.FC = () => {
  return (
    <div className="glass rounded-2xl p-6 border border-brand-border/40 h-full flex flex-col">
      <div className="flex justify-between items-center mb-8">
        <h3 className="text-xs font-black text-white uppercase tracking-[0.2em]">Audit Log</h3>
        <div className="flex gap-2">
          <button className="material-icons text-teal text-lg">format_list_bulleted</button>
          <button className="material-icons text-gray-600 text-lg hover:text-gray-400 transition-colors">grid_view</button>
        </div>
      </div>

      <div className="space-y-6 flex-1">
        {logs.map((log) => (
          <div key={log.id} className="flex gap-4 relative group">
            <div className="flex flex-col items-center">
              <div className={cn(
                "w-8 h-8 rounded-full flex items-center justify-center border transition-transform group-hover:scale-110",
                log.type === 'approved' ? "bg-success/10 border-success/30 text-success" : 
                log.type === 'cancelled' ? "bg-error/10 border-error/30 text-error" : 
                "bg-warning/10 border-warning/30 text-warning"
              )}>
                <span className="material-icons text-sm">
                  {log.type === 'approved' ? 'check' : log.type === 'cancelled' ? 'close' : 'flag'}
                </span>
              </div>
              <div className="w-px h-full bg-brand-border/20 mt-2"></div>
            </div>
            
            <div className="flex-1 pb-6 border-b border-brand-border/10">
              <div className="flex justify-between items-start mb-1">
                <h4 className="text-[13px] font-bold text-white group-hover:text-teal transition-colors">{log.title}</h4>
                <span className="text-[9px] font-bold text-gray-600 uppercase">{log.timestamp}</span>
              </div>
              <p className="text-[11px] text-gray-500 mb-3">{log.subtitle}</p>
              <button className={cn(
                "text-[9px] font-black uppercase tracking-widest border px-3 py-1 rounded transition-all",
                log.type === 'approved' ? "text-success border-success/20 hover:bg-success/5" : 
                log.type === 'cancelled' ? "text-gray-400 border-brand-border/40 hover:text-white" : 
                "text-warning border-warning/20 hover:bg-warning/5"
              )}>
                {log.actionLabel}
              </button>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-4 pt-4 border-t border-brand-border/20">
        <button className="w-full text-[10px] font-black text-gray-500 hover:text-teal uppercase tracking-widest transition-colors flex items-center justify-center gap-2">
          View Full Chain of Custody
          <span className="material-icons text-xs">arrow_forward</span>
        </button>
      </div>
    </div>
  );
};

export default AuditLog;
