
import React from 'react';
import Badge from '../ui/Badge';
import { formatCurrency } from '../../utils';

const SupplierProfileCard: React.FC = () => {
  return (
    <div className="glass rounded-2xl border border-brand-border/60 bg-gradient-to-br from-brand-panel/30 to-brand-navy/60 overflow-hidden">
      <div className="p-8">
        <div className="flex justify-between items-start mb-10">
          <div className="flex gap-6">
            <div className="w-20 h-20 rounded-2xl bg-brand-navy border border-gold/40 flex items-center justify-center p-4 relative shadow-2xl">
              <span className="material-icons text-success text-5xl absolute -top-4 -right-4 bg-brand-navy rounded-full">check_circle</span>
              <img src="https://picsum.photos/seed/lithiumcorp/150/150" alt="LithiumCorp" className="w-full h-full object-contain grayscale opacity-80" />
            </div>
            <div>
              <div className="flex items-center gap-3 mb-1">
                <h2 className="text-2xl font-display font-bold text-white">Alejandro Moreno</h2>
                <Badge variant="gold" icon="star">Gold</Badge>
              </div>
              <p className="text-[10px] font-bold text-gray-500 uppercase tracking-[0.2em] mb-4">Chief Operating Officer • LithiumCorp</p>
              
              <div className="flex gap-8">
                <div>
                  <p className="text-[9px] font-bold text-gray-500 uppercase tracking-widest mb-1">Price / MT</p>
                  <p className="text-xl font-mono font-bold text-white">{formatCurrency(66500)}</p>
                </div>
                <div>
                  <p className="text-[9px] font-bold text-gray-500 uppercase tracking-widest mb-1">Origin</p>
                  <div className="flex items-center gap-2">
                    <span className="w-4 h-3 bg-red-600 rounded-sm"></span>
                    <span className="text-xs font-bold text-white">Chile</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
          
          <button className="px-6 py-3 bg-white/5 border border-brand-border rounded font-bold text-xs text-white uppercase tracking-widest hover:bg-white/10 transition-all flex items-center gap-2">
            Contact Request <span className="material-icons text-sm">mail</span>
          </button>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-8 py-8 border-y border-brand-border/30">
          <div className="text-center">
            <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-1">Purity Grade</p>
            <p className="text-lg font-mono font-bold text-teal">96.5%</p>
          </div>
          <div className="text-center">
            <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-1">Recycled Mat.</p>
            <p className="text-lg font-mono font-bold text-white">Up to 10%</p>
          </div>
          <div className="text-center">
            <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-1">Trust Score</p>
            <div className="flex items-center justify-center gap-1">
              <span className="text-lg font-mono font-bold text-gold">97</span>
              <span className="text-[8px] text-gray-600">/ 100</span>
            </div>
          </div>
          <div className="text-center">
             <button className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-teal/10 border border-teal/30 text-teal text-[9px] font-black uppercase mx-auto">
               <span className="material-icons text-[10px]">verified</span>
               KYC Verified
             </button>
          </div>
        </div>

        <div className="mt-8 flex justify-between items-center">
          <div className="flex gap-4">
            <span className="text-[10px] font-bold text-gray-600 uppercase tracking-widest">Certifications:</span>
            <div className="flex gap-2">
               {['ISO 9001', 'ISO 14001', 'RMI-RMAP'].map(cert => (
                 <span key={cert} className="text-[9px] font-bold text-gray-400 bg-white/5 px-2 py-0.5 rounded border border-white/5">{cert}</span>
               ))}
            </div>
          </div>
          <button className="text-[10px] font-black text-gold uppercase tracking-[0.2em] hover:underline">Download Compliance Pack →</button>
        </div>
      </div>
    </div>
  );
};

export default SupplierProfileCard;
