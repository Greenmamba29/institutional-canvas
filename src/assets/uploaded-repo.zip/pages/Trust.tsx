
import React from 'react';

const Trust: React.FC = () => {
  return (
    <div className="pt-32 pb-24 bg-obsidian-gradient min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <header className="max-w-3xl mb-20">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 border border-primary/20 text-primary text-[10px] font-bold uppercase mb-8">
             <span className="material-symbols-outlined text-sm">shield</span> Institutional Grade Security
          </div>
          <h1 className="text-5xl md:text-6xl font-display font-bold text-white mb-6">Trust is our <br /><span className="text-gold-gradient italic">Most Valuable Commodity</span></h1>
          <p className="text-xl text-gray-400 leading-relaxed mb-10">We've built the world's most rigorous verification infrastructure for the lithium supply chain. Every participant is vetted to ensure seamless, secure transactions.</p>
          <div className="flex gap-4">
             <button className="bg-primary text-black px-8 py-3 rounded font-bold hover:bg-yellow-600 transition-all">Start Verification</button>
             <button className="border border-white/20 text-white px-8 py-3 rounded font-bold hover:bg-white/5 transition-all">Watch Process</button>
          </div>
        </header>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-12 border-y border-white/5 py-12 mb-24 text-center">
           {[
             { val: '100%', label: 'Verified Entities' },
             { val: '$2.4B+', label: 'Secured Volume' },
             { val: 'ISO', label: '27001 Certified' },
             { val: 'Zero', label: 'Fraud Incidents' },
           ].map((stat, i) => (
             <div key={i}>
                <div className="text-4xl font-display font-bold text-white">{stat.val}</div>
                <div className="text-[10px] font-bold uppercase tracking-widest text-gray-500 mt-2">{stat.label}</div>
             </div>
           ))}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-32">
           {[
             { icon: 'verified_user', title: 'KYB & KYC Protocols', desc: 'Deep-dive checks on every entity, structure, and global sanctions list.' },
             { icon: 'history_edu', title: 'Immutable Audit Logs', desc: 'Every transaction and document recorded on a private distributed ledger.' },
             { icon: 'eco', title: 'ESG & Carbon Tracking', desc: 'Scope 3 emission tracking and conflict mineral free verification.' },
           ].map((item, i) => (
             <div key={i} className="bg-card-dark border border-white/5 p-8 rounded-xl hover:border-primary/50 transition-all">
                <div className="w-14 h-14 bg-white/5 rounded-xl flex items-center justify-center mb-6"><span className="material-icons text-primary text-3xl">{item.icon}</span></div>
                <h3 className="text-xl font-bold text-white mb-4">{item.title}</h3>
                <p className="text-sm text-gray-400 leading-relaxed">{item.desc}</p>
             </div>
           ))}
        </div>

        <div className="text-center mb-12"><h2 className="text-3xl font-display font-bold text-white">Verification Tiers</h2></div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {[
            { tier: 'Silver', badge: 'verified', color: 'text-gray-400 border-gray-400/30', checks: ['Identity Passed', 'Tax ID Verified', 'Basic AML'] },
            { tier: 'Gold', badge: 'workspace_premium', color: 'text-primary border-primary/50', active: true, checks: ['3 Years Financials', 'Site Inspection', 'Operational Audit'] },
            { tier: 'Platinum', badge: 'diamond', color: 'text-white border-white/30', checks: ['ESG Integration', 'Real-time API', 'On-Site Audit'] },
          ].map((t, i) => (
            <div key={i} className={`bg-card-dark border rounded-xl p-8 flex flex-col items-center text-center relative ${t.active ? 'border-primary shadow-2xl shadow-primary/10 -translate-y-4' : 'border-white/5'}`}>
               {t.active && <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-primary text-black text-[10px] font-bold px-3 py-1 rounded-full">MOST TRUSTED</div>}
               <div className={`w-16 h-16 rounded-full border-2 flex items-center justify-center mb-6 ${t.color}`}><span className="material-icons text-3xl">{t.badge}</span></div>
               <h3 className="text-2xl font-bold text-white mb-6">{t.tier} Verified</h3>
               <ul className="space-y-4 text-sm text-gray-400 mb-8 w-full">
                 {t.checks.map((c, idx) => <li key={idx} className="flex items-center justify-center gap-2"><span className="material-icons text-primary text-xs">check_circle</span> {c}</li>)}
               </ul>
               <button className="w-full py-3 bg-white/5 hover:bg-white/10 border border-white/10 rounded font-bold text-xs uppercase transition-all">Select Tier</button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Trust;
