
import React from 'react';

const Contact: React.FC = () => {
  return (
    <div className="pt-32 pb-24 bg-background-dark min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <header className="text-center mb-24">
           <h1 className="text-5xl md:text-6xl font-display font-bold text-white mb-6">Connect with <span className="text-gold-gradient italic">Lithium & Lux</span></h1>
           <p className="max-w-2xl mx-auto text-lg text-gray-400 leading-relaxed font-light">Secure enterprise channels for global lithium transactions. Reach our dedicated concierge team for partnership inquiries and trade support.</p>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-16">
          <div className="lg:col-span-4 space-y-8">
             <div className="bg-card-dark border border-white/5 p-8 rounded-xl shadow-2xl hover:border-primary/30 transition-colors group">
                <div className="w-12 h-12 bg-white/5 rounded-lg flex items-center justify-center mb-6 group-hover:bg-primary/10 transition-colors">
                   <span className="material-icons text-primary">business</span>
                </div>
                <h3 className="font-bold text-white text-xl mb-2">Global Headquarters</h3>
                <p className="text-gray-400 text-sm leading-relaxed mb-4">8 Marina View, Asia Square Tower 1<br />Singapore 018960</p>
                <button className="text-primary font-bold text-sm flex items-center gap-2 hover:gap-3 transition-all">Get Directions <span className="material-icons text-sm">arrow_forward</span></button>
             </div>
             <div className="bg-card-dark border border-white/5 p-8 rounded-xl shadow-2xl">
                <h3 className="text-white font-bold text-xl mb-6">Direct Channels</h3>
                <div className="space-y-6">
                   <div className="flex gap-4 items-start">
                      <span className="material-icons text-primary">support_agent</span>
                      <div><p className="text-sm font-bold text-white">Trade Concierge</p><p className="text-xs text-gray-500">support@lithiumlux.com</p></div>
                   </div>
                   <div className="flex gap-4 items-start">
                      <span className="material-icons text-primary">handshake</span>
                      <div><p className="text-sm font-bold text-white">Partnerships</p><p className="text-xs text-gray-500">partners@lithiumlux.com</p></div>
                   </div>
                </div>
             </div>
             <div className="bg-black p-6 rounded-xl border border-white/5 flex flex-col items-center text-center">
                <span className="material-icons text-primary text-4xl mb-4">lock</span>
                <h4 className="text-white font-bold mb-2">Encrypted Comms</h4>
                <p className="text-xs text-gray-500 font-light px-4">All inquiries processed via secure 256-bit SSL gateway.</p>
             </div>
          </div>

          <div className="lg:col-span-8">
             <div className="bg-card-dark border border-white/5 p-10 rounded-xl shadow-2xl relative">
                <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-primary/50 to-transparent"></div>
                <h2 className="text-2xl font-bold text-white mb-2">Send an Inquiry</h2>
                <p className="text-sm text-gray-500 mb-8">Verified suppliers typically receive a response within 4 hours.</p>
                
                <form className="space-y-6">
                   <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-2">
                         <label className="text-xs font-bold text-gray-500 uppercase tracking-widest">First Name</label>
                         <input type="text" placeholder="Jane" className="w-full bg-black border border-white/10 rounded px-4 py-3 text-white focus:ring-primary" />
                      </div>
                      <div className="space-y-2">
                         <label className="text-xs font-bold text-gray-500 uppercase tracking-widest">Last Name</label>
                         <input type="text" placeholder="Doe" className="w-full bg-black border border-white/10 rounded px-4 py-3 text-white focus:ring-primary" />
                      </div>
                   </div>
                   <div className="space-y-2">
                      <label className="text-xs font-bold text-gray-500 uppercase tracking-widest">Work Email</label>
                      <input type="email" placeholder="jane@company.com" className="w-full bg-black border border-white/10 rounded px-4 py-3 text-white focus:ring-primary" />
                   </div>
                   <div className="space-y-2">
                      <label className="text-xs font-bold text-gray-500 uppercase tracking-widest">Message</label>
                      <textarea placeholder="Please describe your requirements..." rows={5} className="w-full bg-black border border-white/10 rounded px-4 py-3 text-white focus:ring-primary"></textarea>
                   </div>
                   <div className="flex items-center gap-3">
                      <input type="checkbox" className="w-4 h-4 rounded bg-black border-white/20 text-primary" />
                      <span className="text-xs text-gray-500">I agree to the Terms of Service and Privacy Policy.</span>
                   </div>
                   <button className="bg-primary text-black font-bold px-10 py-4 rounded shadow-lg hover:bg-yellow-600 transition-all flex items-center gap-2">Submit Inquiry <span className="material-icons text-sm">send</span></button>
                </form>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;
