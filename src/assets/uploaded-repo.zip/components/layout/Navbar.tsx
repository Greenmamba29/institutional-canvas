
import React from 'react';
import { Link } from 'react-router-dom';
import { cn } from '../../utils';
import { useAuth, UserRole } from '../../context/AuthContext';

interface NavbarProps {
  roleDisplay?: string;
}

const Navbar: React.FC<NavbarProps> = ({ roleDisplay }) => {
  const { user, login, logout } = useAuth();

  const handleRoleSwitch = (role: UserRole) => {
    login(role);
  };

  return (
    <nav className="fixed top-0 right-0 left-0 h-16 glass border-b border-brand-border z-50 flex items-center justify-between px-6">
      {/* Left: Branding */}
      <div className="flex items-center gap-4">
        <Link to="/" className="flex items-center gap-2 group">
          <div className="w-8 h-8 rounded-sm rotate-45 border-2 border-gold flex items-center justify-center transition-transform group-hover:scale-110">
            <div className="w-2 h-2 bg-gold"></div>
          </div>
          <span className="font-display text-white font-bold tracking-tight text-lg uppercase hidden sm:inline-block">
            Lithium <span className="text-gold">&</span> Lux
          </span>
        </Link>
        
        <div className="h-6 w-px bg-brand-border mx-2 hidden md:block" />
        
        {/* Role Badge & Switcher */}
        <div className="hidden md:flex items-center gap-2">
           <div className="flex items-center gap-2 px-3 py-1 rounded bg-brand-panel border border-brand-border">
            <span className="w-1.5 h-1.5 rounded-full bg-teal animate-pulse"></span>
            <span className="text-[10px] font-bold text-teal uppercase tracking-widest">{roleDisplay || user?.role || 'Guest'}</span>
          </div>
          
          {/* Demo Role Switcher */}
          <div className="flex bg-black/40 rounded p-0.5 border border-brand-border/30">
            {(['admin', 'supplier', 'buyer'] as UserRole[]).map((r) => (
              <button
                key={r}
                onClick={() => handleRoleSwitch(r)}
                className={cn(
                  "px-2 py-0.5 rounded text-[8px] font-black uppercase tracking-tighter transition-all",
                  user?.role === r ? "bg-gold text-brand-navy" : "text-gray-500 hover:text-white"
                )}
              >
                {r}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Right: Controls & User */}
      <div className="flex items-center gap-2 sm:gap-6">
        <div className="flex items-center gap-1 sm:gap-4 mr-2 sm:mr-4">
          <button className="relative p-2 text-gray-400 hover:text-white transition-colors group">
            <span className="material-icons text-xl">notifications</span>
            <span className="absolute top-1.5 right-1.5 w-4 h-4 bg-error text-[8px] font-bold text-white flex items-center justify-center rounded-full border border-brand-navy">
              12
            </span>
          </button>
          
          <button className="p-2 text-gray-400 hover:text-white transition-colors">
            <span className="material-icons text-xl">settings</span>
          </button>
        </div>

        {/* User Profile */}
        <div className="flex items-center gap-3 px-2 py-1.5 rounded-lg">
          <div className="text-right hidden sm:block">
            <p className="text-xs font-bold text-white">{user?.name || 'Guest User'}</p>
            <p className="text-[9px] text-gray-500 uppercase font-bold tracking-tighter">Verified • {user?.role === 'admin' ? 'System' : 'Gold Tier'}</p>
          </div>
          <div className="w-9 h-9 rounded-full border border-gold/30 p-0.5">
            <img 
              src={user?.avatar || 'https://i.pravatar.cc/150'} 
              alt="User" 
              className="w-full h-full rounded-full grayscale hover:grayscale-0 transition-all"
            />
          </div>
          <button onClick={logout} className="material-icons text-gray-500 hover:text-error text-lg ml-2 transition-colors">logout</button>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
