
import React from 'react';
import { cn } from '../../utils';

interface ProgressBarProps {
  value: number; // 0 to 100
  color?: 'teal' | 'gold' | 'error' | 'success';
  className?: string;
}

const ProgressBar: React.FC<ProgressBarProps> = ({ value, color = 'teal', className }) => {
  const colorMap = {
    teal: 'bg-teal shadow-[0_0_8px_rgba(14,165,233,0.5)]',
    gold: 'bg-gold shadow-[0_0_8px_rgba(212,168,83,0.5)]',
    error: 'bg-error shadow-[0_0_8px_rgba(239,68,68,0.5)]',
    success: 'bg-success shadow-[0_0_8px_rgba(16,185,129,0.5)]',
  };

  return (
    <div className={cn("w-full bg-white/5 rounded-full h-1 overflow-hidden", className)}>
      <div
        className={cn("h-full transition-all duration-1000 ease-out", colorMap[color])}
        style={{ width: `${Math.min(100, Math.max(0, value))}%` }}
      />
    </div>
  );
};

export default ProgressBar;
