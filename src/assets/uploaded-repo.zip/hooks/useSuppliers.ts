
import { useState, useMemo } from 'react';
import { SupplierProfile, VerificationTier } from '../types';

const MOCK_SUPPLIERS: SupplierProfile[] = [
  {
    id: 's1',
    name: 'LithiumCorp',
    region: 'Chile',
    totalSalesYTD: 3750000,
    verificationTier: VerificationTier.GOLD,
    trustScore: 97,
    purityRating: 99.9,
    capacityMT: 12000,
    responseRate: "4.2 hours",
    logoUrl: 'https://picsum.photos/seed/lithiumcorp/128/128',
    lastAuditDate: '2023-11-15',
  },
  {
    id: 's2',
    name: 'EverSource Minerals',
    region: 'Australia',
    totalSalesYTD: 2910000,
    verificationTier: VerificationTier.GOLD,
    trustScore: 94,
    purityRating: 99.5,
    capacityMT: 45000,
    responseRate: "12 hours",
    logoUrl: 'https://picsum.photos/seed/eversource/128/128',
    lastAuditDate: '2024-01-10',
  },
  {
    id: 's3',
    name: 'Metalistica',
    region: 'Argentina',
    totalSalesYTD: 1150000,
    verificationTier: VerificationTier.SILVER,
    trustScore: 88,
    purityRating: 98.2,
    capacityMT: 8000,
    responseRate: "24 hours",
    logoUrl: 'https://picsum.photos/seed/metalistica/128/128',
    lastAuditDate: '2023-09-20',
  },
  {
    id: 's4',
    name: 'Santiago Lithium S.A.',
    region: 'Chile',
    totalSalesYTD: 2100000,
    verificationTier: VerificationTier.SILVER,
    trustScore: 91,
    purityRating: 99.0,
    capacityMT: 21000,
    responseRate: "6 hours",
    logoUrl: 'https://picsum.photos/seed/santiago/128/128',
    lastAuditDate: '2023-12-05',
  },
  {
    id: 's5',
    name: 'Northern Brine Co.',
    region: 'Canada',
    totalSalesYTD: 850000,
    verificationTier: VerificationTier.STANDARD,
    trustScore: 82,
    purityRating: 97.5,
    capacityMT: 5000,
    responseRate: "48 hours",
    logoUrl: 'https://picsum.photos/seed/northern/128/128',
    lastAuditDate: '2023-05-12',
  },
];

export function useSuppliers() {
  const [searchTerm, setSearchTerm] = useState('');
  const [filters, setFilters] = useState({
    tier: [] as string[],
    region: [] as string[],
  });
  const [sortBy, setSortBy] = useState('rating');

  const filteredSuppliers = useMemo(() => {
    return MOCK_SUPPLIERS.filter(s => {
      const matchesSearch = s.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          s.region.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesTier = filters.tier.length === 0 || filters.tier.includes(s.verificationTier);
      const matchesRegion = filters.region.length === 0 || filters.region.includes(s.region);
      
      return matchesSearch && matchesTier && matchesRegion;
    }).sort((a, b) => {
      if (sortBy === 'rating') return b.trustScore - a.trustScore;
      if (sortBy === 'sales') return b.totalSalesYTD - a.totalSalesYTD;
      return 0;
    });
  }, [searchTerm, filters, sortBy]);

  return {
    suppliers: filteredSuppliers,
    searchTerm,
    setSearchTerm,
    filters,
    setFilters,
    sortBy,
    setSortBy,
  };
}
