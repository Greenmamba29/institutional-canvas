
import React from 'react';
import AppLayout from '../components/layout/AppLayout';
import SupplierSidebar from '../components/layout/SupplierSidebar';
import SupplierStats from '../components/supplier/SupplierStats';
import SupplierProfileCard from '../components/supplier/SupplierProfileCard';
import LiveRFQsTable from '../components/supplier/LiveRFQsTable';
import WeeklyAuctionSnapshot from '../components/supplier/WeeklyAuctionSnapshot';
import UpcomingAuctions from '../components/supplier/UpcomingAuctions';
import { cn } from '../utils';

const SupplierDashboard: React.FC = () => {
  return (
    <AppLayout 
      sidebar={<SupplierSidebar />}
      headerTitle="Supplier Performance Terminal"
      headerBreadcrumbs={[
        { label: "Platform" },
        { label: "Supplier Desk" },
        { label: "Dashboard", active: true }
      ]}
      tabs={['Overview', 'My Listings', 'Financials']}
    >
      <div className="space-y-10 pb-12">
        {/* Top Metrics Row */}
        <section>
          <SupplierStats />
        </section>

        {/* Hero Visualization Section */}
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-8">
          <div className="xl:col-span-8">
            <WeeklyAuctionSnapshot />
          </div>
          <div className="xl:col-span-4">
            <UpcomingAuctions />
          </div>
        </div>

        {/* Main Content Grid */}
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-8">
          {/* Left Column: Activity & Charts */}
          <div className="xl:col-span-8 space-y-8">
            {/* Live RFQs Table */}
            <LiveRFQsTable />

            {/* Quick Supplier Actions */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="glass p-6 rounded-2xl border border-brand-border/40 flex items-center gap-6 group hover:border-gold/30 transition-all cursor-pointer">
                <div className="w-16 h-16 rounded-2xl bg-gold/5 flex items-center justify-center border border-gold/20 group-hover:bg-gold/10 transition-colors">
                  <span className="material-icons text-3xl text-gold">local_shipping</span>
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white">Logistics Fulfillment</h4>
                  <p className="text-xs text-gray-500 mt-1">Pending dispatch for Order #77421 (Santiago Port).</p>
                </div>
              </div>
              <div className="glass p-6 rounded-2xl border border-brand-border/40 flex items-center gap-6 group hover:border-teal/30 transition-all cursor-pointer">
                <div className="w-16 h-16 rounded-2xl bg-teal/5 flex items-center justify-center border border-teal/20 group-hover:bg-teal/10 transition-colors">
                  <span className="material-icons text-3xl text-teal">receipt_long</span>
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white">Pending Settlements</h4>
                  <p className="text-xs text-gray-500 mt-1">3 Escrow releases awaiting final verification.</p>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Profile & Badges */}
          <div className="xl:col-span-4 space-y-8">
            <SupplierProfileCard />
            
            <div className="glass p-6 rounded-2xl border border-brand-border/40">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-xs font-black text-white uppercase tracking-[0.2em]">Verification Pipeline</h3>
                <span className="material-icons text-gray-600 text-sm">info_outline</span>
              </div>
              
              <div className="space-y-6">
                {[
                  { label: 'Site Inspection 2024', status: 'Approved', color: 'text-success', icon: 'check_circle' },
                  { label: 'RMI Sustainability Audit', status: 'In Review', color: 'text-warning', icon: 'hourglass_empty' },
                  { label: 'LME Grade Registration', status: 'Active', color: 'text-teal', icon: 'verified' },
                ].map((step, i) => (
                  <div key={i} className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <span className={cn("material-icons text-sm", step.color)}>{step.icon}</span>
                      <span className="text-[11px] font-medium text-gray-400">{step.label}</span>
                    </div>
                    <span className={cn("text-[9px] font-black uppercase tracking-widest", step.color)}>{step.status}</span>
                  </div>
                ))}
              </div>
              
              <button className="w-full mt-8 py-3 bg-brand-navy border border-brand-border rounded text-[10px] font-bold text-gray-500 hover:text-white transition-all uppercase tracking-widest">
                Upgrade Verification Tier
              </button>
            </div>
          </div>
        </div>
      </div>
    </AppLayout>
  );
};

export default SupplierDashboard;
