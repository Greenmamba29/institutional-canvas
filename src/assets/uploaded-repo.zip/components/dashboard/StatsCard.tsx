
import React from 'react';
import { cn, formatCurrency } from '../../utils';

interface StatsCardProps {
  value: string | number;
  label: string;
  trend?: 'up' | 'down';
  trendValue?: string;
  subtitle?: string;
  sparklineData?: number[];
  isCurrency?: boolean;
}

const StatsCard: React.FC<StatsCardProps> = ({
  value,
  label,
  trend,
  trendValue,
  subtitle,
  sparklineData,
  isCurrency = false,
}) => {
  const displayValue = isCurrency && typeof value === 'number' ? formatCurrency(value) : value;

  return (
    <div className="glass p-5 rounded-xl border border-brand-border/40 hover:border-gold/40 transition-all duration-300 group cursor-default">
      <div className="flex justify-between items-start mb-4">
        <div>
          <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-1">{label}</p>
          <div className="flex items-baseline gap-2">
            <h3 className="text-2xl font-mono font-bold text-white group-hover:text-gold transition-colors">
              {displayValue}
            </h3>
            {subtitle && (
              <span className="text-[10px] text-gray-500 font-bold uppercase">{subtitle}</span>
            )}
          </div>
        </div>
        
        {trend && (
          <div className={cn(
            "flex items-center gap-0.5 px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-tighter",
            trend === 'up' ? "bg-success/10 text-success border border-success/20" : "bg-error/10 text-error border border-error/20"
          )}>
            <span className="material-icons text-[12px]">{trend === 'up' ? 'north' : 'south'}</span>
            {trendValue}
          </div>
        )}
      </div>

      {sparklineData && (
        <div className="h-10 w-full mt-2">
          <svg viewBox="0 0 100 30" className="w-full h-full overflow-visible" preserveAspectRatio="none">
            <defs>
              <linearGradient id="sparklineGradient" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#D4A853" stopOpacity="0.4" />
                <stop offset="100%" stopColor="#D4A853" stopOpacity="0" />
              </linearGradient>
            </defs>
            <path
              d={`M ${sparklineData.map((d, i) => `${(i / (sparklineData.length - 1)) * 100} ${30 - d}`).join(' L ')}`}
              fill="none"
              stroke="#D4A853"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="drop-shadow-[0_0_5px_rgba(212,168,83,0.3)]"
            />
            <path
              d={`M ${sparklineData.map((d, i) => `${(i / (sparklineData.length - 1)) * 100} ${30 - d}`).join(' L ')} L 100 30 L 0 30 Z`}
              fill="url(#sparklineGradient)"
            />
          </svg>
        </div>
      )}
    </div>
  );
};

export default StatsCard;
