
import React, { createContext, useContext, useState, ReactNode } from 'react';

export type UserRole = 'admin' | 'supplier' | 'buyer';

interface User {
  name: string;
  role: UserRole;
  avatar: string;
}

interface AuthContextType {
  user: User | null;
  login: (role: UserRole) => void;
  logout: () => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>({
    name: 'Sarah Edwards',
    role: 'admin',
    avatar: 'https://i.pravatar.cc/150?u=sarah_edwards'
  });

  const login = (role: UserRole) => {
    const names = {
      admin: 'Sarah Edwards',
      supplier: 'Diego Santos',
      buyer: 'Marcus Thorne'
    };
    const avatars = {
      admin: 'https://i.pravatar.cc/150?u=sarah_edwards',
      supplier: 'https://i.pravatar.cc/150?u=diego',
      buyer: 'https://i.pravatar.cc/150?u=marcus'
    };
    setUser({ name: names[role], role, avatar: avatars[role] });
  };

  const logout = () => setUser(null);

  return (
    <AuthContext.Provider value={{ user, login, logout, isAuthenticated: !!user }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
