
import React from 'react';
import { Link } from 'react-router-dom';

const PublicNav: React.FC = () => (
  <nav className="fixed top-0 left-0 right-0 z-[100] h-20 bg-transparent flex items-center justify-between px-10">
    <Link to="/" className="flex items-center gap-2">
      <div className="w-8 h-8 rounded-sm rotate-45 border-2 border-gold flex items-center justify-center">
        <div className="w-2 h-2 bg-gold"></div>
      </div>
      <span className="font-display text-white font-bold tracking-tight text-xl uppercase">Lithium & Lux</span>
    </Link>
    <div className="hidden lg:flex items-center gap-10">
      {['Marketplace', 'Auctions', 'Intelligence', 'Architecture'].map(item => (
        <Link 
          key={item} 
          to={`/${item.toLowerCase()}`} 
          className="text-xs font-bold text-gray-400 hover:text-white uppercase tracking-widest transition-colors"
        >
          {item}
        </Link>
      ))}
    </div>
    <div className="flex items-center gap-4">
      <Link to="/dashboard" className="px-6 py-2 bg-gold text-brand-navy font-bold rounded text-xs uppercase tracking-widest hover:bg-gold-bright transition-all">
        Launch Console
      </Link>
    </div>
  </nav>
);

const Home: React.FC = () => {
  return (
    <div className="overflow-hidden bg-cosmic-radial min-h-screen w-full">
      <PublicNav />
      
      {/* Hero Section - Optimized spacing */}
      <section className="relative pt-32 pb-24 lg:pt-40 lg:pb-32 flex flex-col items-center justify-center min-h-[90vh]">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1000px] h-[600px] bg-teal/10 blur-[150px] rounded-full opacity-50"></div>
          <div className="absolute bottom-0 right-0 w-[800px] h-[500px] bg-gold/5 blur-[120px] rounded-full opacity-30"></div>
        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-6 text-center">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full border border-gold/30 bg-gold/5 text-gold text-xs font-bold tracking-[0.2em] uppercase mb-8 animate-fade-in">
             Institutional Lithium Sourcing
          </div>
          <h1 className="text-6xl md:text-8xl font-display font-bold text-white mb-6 leading-tight tracking-tight">
             The Future of <br />
             <span className="text-gold-gradient italic">Trade Integrity</span>
          </h1>
          <p className="mt-4 text-xl md:text-2xl text-gray-400 max-w-3xl mx-auto leading-relaxed font-light">
             Enterprise-grade lithium procurement for the global energy transition. 
             Connecting verified sources to high-volume demand through immutable trust.
          </p>
          <div className="mt-12 flex flex-col sm:flex-row gap-6 justify-center items-center">
            <Link to="/marketplace" className="w-full sm:w-auto px-10 py-5 bg-gold text-brand-navy font-bold rounded shadow-2xl hover:bg-gold-bright transition-all text-center border border-gold uppercase tracking-widest text-sm">
              Explore Directory
            </Link>
            <Link to="/contact" className="w-full sm:w-auto px-10 py-5 glass text-white font-bold rounded hover:bg-white/10 transition-all flex items-center justify-center gap-3 shadow-xl uppercase tracking-widest text-sm">
              <span>Request Access</span>
              <span className="material-icons text-sm">north_east</span>
            </Link>
          </div>

          <div className="mt-24 grid grid-cols-1 md:grid-cols-4 gap-12 border-t border-brand-border pt-16 max-w-5xl mx-auto">
            <div className="space-y-2">
               <p className="text-5xl font-mono font-bold text-gold">$15.2M</p>
               <p className="text-[10px] uppercase font-bold text-gray-500 tracking-[0.2em]">GMV YTD</p>
            </div>
            <div className="space-y-2 border-x border-brand-border px-8">
               <p className="text-5xl font-mono font-bold text-gold">147</p>
               <p className="text-[10px] uppercase font-bold text-gray-500 tracking-[0.2em]">Verified Suppliers</p>
            </div>
            <div className="space-y-2 border-r border-brand-border pr-8">
               <p className="text-5xl font-mono font-bold text-gold">4H</p>
               <p className="text-[10px] uppercase font-bold text-gray-500 tracking-[0.2em]">Avg. Sourcing</p>
            </div>
            <div className="space-y-2">
               <p className="text-5xl font-mono font-bold text-gold">99.9%</p>
               <p className="text-[10px] uppercase font-bold text-gray-500 tracking-[0.2em]">Purity Grade</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer Minimal */}
      <footer className="py-12 border-t border-brand-border bg-brand-navy">
         <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center gap-8">
            <div className="flex items-center gap-2">
               <div className="w-6 h-6 rounded-sm rotate-45 border border-gold flex items-center justify-center">
                  <div className="w-1.5 h-1.5 bg-gold"></div>
               </div>
               <span className="font-display text-white font-bold tracking-tight uppercase text-sm">Lithium & Lux</span>
            </div>
            <div className="flex gap-8 text-[10px] font-bold text-gray-500 uppercase tracking-widest">
               <Link to="/trust" className="hover:text-gold">Privacy</Link>
               <Link to="/trust" className="hover:text-gold">Compliance</Link>
               <Link to="/contact" className="hover:text-gold">Contact</Link>
            </div>
            <p className="text-[10px] text-gray-600 font-mono">© 2024 LITHIUM & LUX. INSTITUTIONAL GRADE TRADING.</p>
         </div>
      </footer>
    </div>
  );
};

export default Home;
