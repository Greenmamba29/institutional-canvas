
export default {
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        brand: {
          navy: "#0A1628",
          deep: "#0D1B2A",
          panel: "#1A2D42",
          glass: "rgba(30, 58, 95, 0.8)",
          border: "#2D4A6F",
        },
        accent: {
          DEFAULT: "#D4A853", // Primary Gold
          bright: "#F5C463",
          muted: "#B8954F",
        },
        teal: {
          DEFAULT: "#0EA5E9",
          dark: "#0284C7",
          light: "#38BDF8",
        },
        success: "#10B981",
        warning: "#F59E0B",
        error: "#EF4444",
        muted: {
          DEFAULT: "#A0AEC0",
          dark: "#718096",
        },
      },
      fontFamily: {
        sans: ["Inter", "system-ui", "sans-serif"],
        display: ["Playfair Display", "serif"],
        mono: ["JetBrains Mono", "monospace"],
      },
      backgroundImage: {
        'cosmic-radial': 'radial-gradient(circle at 50% 0%, #1A2D42 0%, #0A1628 80%)',
        'glass-gradient': 'linear-gradient(145deg, rgba(255,255,255,0.05) 0%, rgba(255,255,255,0) 100%)',
        'gold-gradient': 'linear-gradient(to right, #D4A853, #F5C463, #B8954F)',
      },
      animation: {
        'glow': 'glow 2s ease-in-out infinite alternate',
        'pulse-slow': 'pulse 4s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'fade-in': 'fadeIn 0.5s ease-out',
        'star-twinkle': 'twinkle 3s ease-in-out infinite',
      },
      keyframes: {
        glow: {
          '0%': { boxShadow: '0 0 5px rgba(212, 168, 83, 0.2)' },
          '100%': { boxShadow: '0 0 20px rgba(212, 168, 83, 0.5)' },
        },
        fadeIn: {
          '0%': { opacity: '0', transform: 'translateY(10px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        twinkle: {
          '0%, 100%': { opacity: '0.3', transform: 'scale(1)' },
          '50%': { opacity: '1', transform: 'scale(1.2)' },
        },
      },
      borderRadius: {
        'xl': '12px',
        'lg': '8px',
        'md': '6px',
        'sm': '4px',
      },
    },
  },
  plugins: [],
}
