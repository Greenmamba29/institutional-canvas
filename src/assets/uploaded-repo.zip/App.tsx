
import React from 'react';
import { HashRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import ProtectedRoute from './components/auth/ProtectedRoute';

// Pages
import Home from './pages/Home';
import Dashboard from './pages/Dashboard';
import SupplierDashboard from './pages/SupplierDashboard';
import Marketplace from './pages/Marketplace';
import Auctions from './pages/Auctions';
import Intelligence from './pages/Intelligence';
import Trust from './pages/Trust';
import Resources from './pages/Resources';
import About from './pages/About';
import Contact from './pages/Contact';
import Architecture from './pages/Architecture';
import Directory from './pages/Directory';

const DashboardRedirect: React.FC = () => {
  const { user } = useAuth();
  if (!user) return <Navigate to="/" replace />;
  
  switch (user.role) {
    case 'admin': return <Dashboard />;
    case 'supplier': return <SupplierDashboard />;
    case 'buyer': return <Dashboard />; // Buyer can use the standard dash for now
    default: return <Navigate to="/" replace />;
  }
};

const AppRoutes: React.FC = () => {
  return (
    <Routes>
      {/* Public Routes */}
      <Route path="/" element={<Home />} />
      <Route path="/marketplace" element={<Marketplace />} />
      <Route path="/directory" element={<Directory />} />
      <Route path="/auctions" element={<Auctions />} />
      <Route path="/intelligence" element={<Intelligence />} />
      <Route path="/trust" element={<Trust />} />
      <Route path="/resources" element={<Resources />} />
      <Route path="/about" element={<About />} />
      <Route path="/contact" element={<Contact />} />
      <Route path="/architecture" element={<Architecture />} />

      {/* Auth Guarded Dashboards */}
      <Route 
        path="/dashboard" 
        element={
          <ProtectedRoute>
            <DashboardRedirect />
          </ProtectedRoute>
        } 
      />
      
      <Route 
        path="/admin/dashboard" 
        element={
          <ProtectedRoute allowedRoles={['admin']}>
            <Dashboard />
          </ProtectedRoute>
        } 
      />

      <Route 
        path="/supplier/dashboard" 
        element={
          <ProtectedRoute allowedRoles={['supplier']}>
            <SupplierDashboard />
          </ProtectedRoute>
        } 
      />

      <Route 
        path="/buyer/dashboard" 
        element={
          <ProtectedRoute allowedRoles={['buyer']}>
            <Dashboard />
          </ProtectedRoute>
        } 
      />

      {/* Catch-all */}
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
};

const App: React.FC = () => {
  return (
    <AuthProvider>
      <Router>
        <div className="flex min-h-screen bg-brand-navy text-white selection:bg-gold/30 selection:text-white">
          <AppRoutes />
        </div>
      </Router>
    </AuthProvider>
  );
};

export default App;
