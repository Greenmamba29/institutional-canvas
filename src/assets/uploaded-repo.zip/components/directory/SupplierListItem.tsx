
import React from 'react';
import { SupplierProfile } from '../../types';
import VerificationBadge, { VerificationTier } from '../ui/VerificationBadge';
import { formatCurrency } from '../../utils';

interface SupplierListItemProps {
  supplier: SupplierProfile;
  onClick: (id: string) => void;
}

const SupplierListItem: React.FC<SupplierListItemProps> = ({ supplier, onClick }) => {
  return (
    <div 
      onClick={() => onClick(supplier.id)}
      className="glass p-1 rounded-xl hover:border-gold/30 transition-all duration-300 group cursor-pointer"
    >
      <div className="bg-white/[0.02] p-4 rounded-lg flex flex-col md:flex-row items-center gap-6">
        <div className="w-12 h-12 rounded-lg bg-brand-navy border border-brand-border/40 p-2 group-hover:border-gold/40 flex-shrink-0">
          <img src={supplier.logoUrl} className="w-full h-full object-contain grayscale group-hover:grayscale-0 opacity-60 group-hover:opacity-100" />
        </div>
        
        <div className="flex-1">
          <div className="flex items-center gap-3 mb-1">
            <h3 className="text-base font-bold text-white group-hover:text-gold transition-colors">{supplier.name}</h3>
            <VerificationBadge tier={supplier.verificationTier.toLowerCase() as VerificationTier} />
          </div>
          <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest flex items-center gap-1">
            <span className="material-icons text-xs">location_on</span> {supplier.region}
          </p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 gap-8 px-6 border-x border-brand-border/10 hidden lg:grid">
          <div>
            <p className="text-[9px] font-bold text-gray-500 uppercase tracking-widest mb-0.5">Capacity</p>
            <p className="text-xs font-mono font-bold text-white">{supplier.capacityMT.toLocaleString()} MT/y</p>
          </div>
          <div>
            <p className="text-[9px] font-bold text-gray-500 uppercase tracking-widest mb-0.5">Response</p>
            <p className="text-xs font-mono font-bold text-teal">{supplier.responseRate}</p>
          </div>
          <div>
            <p className="text-[9px] font-bold text-gray-500 uppercase tracking-widest mb-0.5">Purity</p>
            <p className="text-xs font-mono font-bold text-white">{supplier.purityRating}%</p>
          </div>
        </div>

        <div className="text-right pr-4 hidden sm:block">
          <p className="text-[9px] font-bold text-gray-500 uppercase tracking-widest mb-0.5">Trust Score</p>
          <p className="text-lg font-mono font-bold text-gold">{supplier.trustScore}<span className="text-[10px] text-gray-600">/100</span></p>
        </div>

        <div className="flex gap-2">
          <button className="px-4 py-2 rounded-lg bg-white/5 border border-brand-border/40 text-[9px] font-black text-gray-400 hover:text-white uppercase tracking-widest">
            Details
          </button>
          <button className="px-4 py-2 rounded-lg bg-gold text-brand-navy text-[9px] font-black uppercase tracking-widest shadow-lg shadow-gold/20">
            RFQ
          </button>
        </div>
      </div>
    </div>
  );
};

export default SupplierListItem;
