
import React from 'react';
import HeroStats from './HeroStats';
import PlatformSummary from './PlatformSummary';

const OverviewHeader: React.FC = () => {
  return (
    <div className="space-y-6">
      {/* System Alert Bar - Integrated into the hero top */}
      <div className="flex items-center justify-between p-3.5 rounded-xl bg-teal/10 border border-teal/20 shadow-lg">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-teal/20 flex items-center justify-center">
            <span className="material-icons text-teal text-sm">notifications</span>
          </div>
          <p className="text-[11px] text-gray-300">
            <span className="font-bold text-white uppercase tracking-tighter mr-2">System Alert:</span> Chilean export quota re-allocations are live. Check the directory for updated capacity.
          </p>
        </div>
        <button className="text-[10px] font-black text-teal uppercase hover:underline tracking-widest px-4 py-1">View Details</button>
      </div>

      {/* Hero Content Grid - Optimized for density */}
      <div className="flex flex-col xl:flex-row gap-6 items-stretch">
        <div className="xl:flex-1">
          <HeroStats />
        </div>
        <div className="xl:w-[360px] flex-shrink-0">
          <PlatformSummary />
        </div>
      </div>
    </div>
  );
};

export default OverviewHeader;
