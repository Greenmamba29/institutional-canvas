
import React, { useState } from 'react';
import AppLayout from '../components/layout/AppLayout';
import AuctionDetail from '../components/auction/AuctionDetail';

const Auctions: React.FC = () => {
  const [selectedLot, setSelectedLot] = useState<string | null>('L-8842');

  return (
    <AppLayout
      headerTitle="Institutional Auction Terminal"
      headerBreadcrumbs={[
        { label: "Platform" },
        { label: "Marketplace" },
        { label: "Auctions", active: true }
      ]}
      tabs={['Active Lots', 'Schedule', 'Settlements']}
    >
      <div className="space-y-12 pb-24">
        {/* Market Status Overview */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="glass p-6 rounded-2xl border border-brand-border/40">
             <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-1">Live Events</p>
             <h3 className="text-3xl font-mono font-bold text-white">14</h3>
             <p className="text-[9px] text-success font-black uppercase mt-1">High Volatility Detected</p>
          </div>
          <div className="glass p-6 rounded-2xl border border-brand-border/40">
             <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-1">Global GMV (24h)</p>
             <h3 className="text-3xl font-mono font-bold text-gold">$8.4M</h3>
             <p className="text-[9px] text-teal font-black uppercase mt-1">Institutional Bidding Level</p>
          </div>
          <div className="glass p-6 rounded-2xl border border-brand-border/40">
             <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-1">Participants</p>
             <h3 className="text-3xl font-mono font-bold text-white">142</h3>
             <p className="text-[9px] text-gray-500 font-black uppercase mt-1">Verified Tier-1 Only</p>
          </div>
        </div>

        {/* Featured Live Auction Detail */}
        {selectedLot === 'L-8842' ? (
          <section>
            <div className="flex justify-between items-center mb-8">
               <h3 className="text-xs font-black text-white uppercase tracking-[0.2em]">Featured Live Auction</h3>
               <button 
                 onClick={() => setSelectedLot(null)}
                 className="text-[10px] font-bold text-gray-500 hover:text-white transition-all uppercase"
               >
                 Back to List
               </button>
            </div>
            <AuctionDetail 
              id="8842"
              material="Lithium Hydroxide Monohydrate"
              supplier="LithiumCorp (Chile Operations)"
              initialBid={66500}
              lotSize="500 MT"
              purity="99.9% Battery Grade"
              origin="Chile"
            />
          </section>
        ) : (
          <div className="glass rounded-2xl border border-brand-border/40 p-20 text-center">
             <span className="material-icons text-6xl text-brand-border/40 mb-4">gavel</span>
             <h3 className="text-xl font-bold text-white mb-2">Select a Lot to Start Bidding</h3>
             <p className="text-gray-500 text-sm mb-8">Verification of institutional status is required for bidding access.</p>
             <button 
               onClick={() => setSelectedLot('L-8842')}
               className="px-10 py-4 bg-gold text-brand-navy font-bold rounded shadow-lg uppercase tracking-widest text-xs"
             >
               View Active Lot #8842
             </button>
          </div>
        )}
      </div>
    </AppLayout>
  );
};

export default Auctions;
