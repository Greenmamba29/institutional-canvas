
import React from 'react';
import { cn } from '../../utils';

export type VerificationTier = 'gold' | 'silver' | 'standard';

interface VerificationBadgeProps {
  tier: VerificationTier;
  className?: string;
}

const VerificationBadge: React.FC<VerificationBadgeProps> = ({ tier, className }) => {
  const styles = {
    gold: "bg-gold text-brand-navy border-gold shadow-[0_0_10px_rgba(212,168,83,0.3)]",
    silver: "bg-gray-400 text-brand-navy border-gray-400",
    standard: "bg-transparent text-gray-400 border-gray-600",
  };

  const icons = {
    gold: "star",
    silver: "verified",
    standard: "check_circle",
  };

  return (
    <span className={cn(
      "inline-flex items-center gap-1 px-2 py-0.5 rounded text-[9px] font-black uppercase tracking-tighter border",
      styles[tier],
      className
    )}>
      <span className="material-icons text-[10px]">{icons[tier]}</span>
      {tier}
    </span>
  );
};

export default VerificationBadge;
