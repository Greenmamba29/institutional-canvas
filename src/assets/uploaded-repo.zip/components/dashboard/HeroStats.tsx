
import React from 'react';
import StatsCard from './StatsCard';

const HeroStats: React.FC = () => {
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-2 2xl:grid-cols-4 gap-6">
      <StatsCard 
        label="Gross Market Value" 
        value="$4MV" 
        subtitle="YTD #237"
        trend="up"
        trendValue="8.2%"
      />
      <StatsCard 
        label="Today's GMV" 
        value={4270} 
        isCurrency={true}
        trend="up"
        trendValue="+6.1%"
      />
      <StatsCard 
        label="Total Transactions" 
        value="526" 
        sparklineData={[10, 15, 8, 22, 18, 25, 20]}
      />
      <StatsCard 
        label="Escrow Contracts" 
        value="263" 
        trend="up"
        trendValue="+14"
      />
    </div>
  );
};

export default HeroStats;
