
import React from 'react';

interface DirectoryFiltersProps {
  filters: { tier: string[]; region: string[] };
  setFilters: React.Dispatch<React.SetStateAction<{ tier: string[]; region: string[] }>>;
  onClear: () => void;
}

const DirectoryFilters: React.FC<DirectoryFiltersProps> = ({ filters, setFilters, onClear }) => {
  const toggleFilter = (type: 'tier' | 'region', value: string) => {
    setFilters(prev => ({
      ...prev,
      [type]: prev[type].includes(value) 
        ? prev[type].filter(v => v !== value) 
        : [...prev[type], value]
    }));
  };

  return (
    <aside className="w-full lg:w-72 flex-shrink-0">
      <div className="glass p-8 rounded-2xl border border-brand-border/40 sticky top-24">
        <div className="flex justify-between items-center mb-8">
          <h3 className="font-bold text-white flex items-center gap-2">
            <span className="material-icons text-gold text-lg">tune</span> Filters
          </h3>
          <button 
            onClick={onClear}
            className="text-[10px] font-bold text-gray-600 hover:text-white uppercase tracking-widest transition-colors"
          >
            Clear
          </button>
        </div>
        
        <div className="space-y-10">
          <div>
            <h4 className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-6 border-b border-brand-border/20 pb-2">Verification Tier</h4>
            <div className="space-y-4">
              {['Gold', 'Silver', 'Standard'].map(tier => (
                <label key={tier} className="flex items-center gap-3 cursor-pointer group">
                  <input 
                    type="checkbox" 
                    checked={filters.tier.includes(tier)}
                    onChange={() => toggleFilter('tier', tier)}
                    className="w-4 h-4 rounded border-brand-border bg-brand-navy text-gold focus:ring-gold" 
                  />
                  <span className={`text-[11px] font-bold uppercase tracking-widest ${
                    tier === 'Gold' ? 'text-gold' : tier === 'Silver' ? 'text-gray-300' : 'text-gray-500'
                  }`}>
                    {tier} Verified
                  </span>
                </label>
              ))}
            </div>
          </div>

          <div>
            <h4 className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-6 border-b border-brand-border/20 pb-2">Geographic Origin</h4>
            <div className="space-y-4">
              {['Chile', 'Australia', 'Argentina', 'Canada', 'USA'].map(region => (
                <label key={region} className="flex items-center gap-3 cursor-pointer group">
                  <input 
                    type="checkbox" 
                    checked={filters.region.includes(region)}
                    onChange={() => toggleFilter('region', region)}
                    className="w-4 h-4 rounded border-brand-border bg-brand-navy text-gold focus:ring-gold" 
                  />
                  <span className="text-xs text-gray-400 group-hover:text-white transition-colors">{region}</span>
                </label>
              ))}
            </div>
          </div>

          <div>
            <h4 className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-6 border-b border-brand-border/20 pb-2">Product Chemistry</h4>
            <div className="space-y-4">
              {['Li Carbonate', 'Li Hydroxide', 'Li Chloride', 'Spodumene'].map(type => (
                <label key={type} className="flex items-center gap-3 cursor-pointer group opacity-50 pointer-events-none">
                  <input type="checkbox" className="w-4 h-4 rounded border-brand-border bg-brand-navy text-gold" disabled />
                  <span className="text-xs text-gray-400">{type}</span>
                </label>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-12 p-4 rounded-xl bg-teal/5 border border-teal/20 text-center">
           <p className="text-[9px] text-teal font-black uppercase tracking-tighter mb-2">Institutional Access</p>
           <p className="text-[10px] text-gray-500 font-medium leading-relaxed">Advanced purity filters require Platinum membership.</p>
        </div>
      </div>
    </aside>
  );
};

export default DirectoryFilters;
