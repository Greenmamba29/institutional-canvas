
import React, { useState } from 'react';
import AppLayout from '../components/layout/AppLayout';
import DirectoryFilters from '../components/directory/DirectoryFilters';
import DirectoryGrid from '../components/directory/DirectoryGrid';
import SupplierDetailDrawer from '../components/directory/SupplierDetailDrawer';
import { useSuppliers } from '../hooks/useSuppliers';

const Directory: React.FC = () => {
  const { 
    suppliers, 
    searchTerm, 
    setSearchTerm, 
    filters, 
    setFilters 
  } = useSuppliers();
  
  const [selectedSupplierId, setSelectedSupplierId] = useState<string | null>(null);

  const selectedSupplier = suppliers.find(s => s.id === selectedSupplierId) || null;

  return (
    <AppLayout
      headerTitle="Global Supplier Directory"
      headerBreadcrumbs={[
        { label: "Platform" },
        { label: "Intelligence Desk" },
        { label: "Verified Directory", active: true }
      ]}
      tabs={['All Suppliers', 'Preferred', 'Verification Queue']}
    >
      <div className="space-y-10 pb-24">
        {/* Search Bar Row */}
        <div className="glass p-1 rounded-2xl border border-brand-border/40 group overflow-hidden">
          <div className="bg-white/[0.02] p-4 flex gap-4 items-center">
            <div className="relative flex-1">
              <span className="material-icons absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 group-focus-within:text-gold transition-colors">search</span>
              <input 
                type="text" 
                placeholder="Search global network by supplier name, chemistry spec, or mineral origin..." 
                className="w-full pl-12 pr-4 py-4 bg-brand-navy border border-brand-border/20 rounded-xl text-white font-medium focus:ring-gold focus:border-gold/50 text-sm transition-all"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <button className="bg-gold text-brand-navy font-black px-10 py-4 rounded-xl shadow-xl shadow-gold/20 uppercase tracking-[0.2em] text-xs hover:bg-gold-bright transition-all">
              Execute Search
            </button>
          </div>
        </div>

        {/* Directory Layout */}
        <div className="flex flex-col lg:flex-row gap-10">
          <DirectoryFilters 
            filters={filters} 
            setFilters={setFilters} 
            onClear={() => {
              setFilters({ tier: [], region: [] });
              setSearchTerm('');
            }}
          />
          <DirectoryGrid 
            suppliers={suppliers} 
            onSupplierClick={(id) => setSelectedSupplierId(id)} 
          />
        </div>
      </div>

      <SupplierDetailDrawer 
        supplier={selectedSupplier} 
        onClose={() => setSelectedSupplierId(null)} 
      />
    </AppLayout>
  );
};

export default Directory;
