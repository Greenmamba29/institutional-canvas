
import React from 'react';
import { cn, formatCurrency } from '../../utils';
import ProgressBar from '../ui/ProgressBar';
import CountdownTimer from '../ui/CountdownTimer';

interface RFQRow {
  id: string;
  company: string;
  flag: string;
  product: string;
  quantity: string;
  expiresAt: Date;
  matchPercent: number;
  value: string;
  escrowTime: string;
}

const mockRFQs: RFQRow[] = [
  {
    id: '1',
    company: 'AltraTech Industries',
    flag: '🇺🇸',
    product: 'Lithium Hydroxide',
    quantity: '20 MT',
    expiresAt: new Date(Date.now() + 3.58 * 60 * 60 * 1000),
    matchPercent: 52,
    value: '$110m',
    escrowTime: '3h 25m',
  },
  {
    id: '2',
    company: 'EV Energy Solutions',
    flag: '🇩🇪',
    product: 'Lithium Hydroxide (Private)',
    quantity: '500 MT',
    expiresAt: new Date(Date.now() + 3.98 * 60 * 60 * 1000),
    matchPercent: 29,
    value: '$116m',
    escrowTime: '2h 50m',
  },
  {
    id: '3',
    company: 'Voltum Batteries',
    flag: '🇧🇷',
    product: 'Spodumene',
    quantity: '420 MT',
    expiresAt: new Date(Date.now() + 5.18 * 60 * 60 * 1000),
    matchPercent: 50,
    value: '$HeFa',
    escrowTime: '3h 50m',
  },
];

const LiveRFQsTable: React.FC = () => {
  return (
    <div className="glass rounded-2xl border border-brand-border/40 overflow-hidden">
      <div className="p-6 border-b border-brand-border/20 flex justify-between items-center">
        <div>
          <h3 className="text-xs font-black text-white uppercase tracking-[0.2em]">Live RFQs</h3>
          <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest mt-1">Institutional Buyer Requests in Market</p>
        </div>
        <div className="flex gap-2">
          <button className="p-2 rounded hover:bg-white/5 transition-colors">
            <span className="material-symbols-outlined text-gray-500">filter_list</span>
          </button>
          <button className="p-2 rounded hover:bg-white/5 transition-colors">
            <span className="material-symbols-outlined text-gray-500">sync</span>
          </button>
        </div>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead className="bg-brand-navy/50 sticky top-0 z-10">
            <tr className="border-b border-brand-border/20">
              <th className="px-6 py-4 text-[9px] font-black text-gray-500 uppercase tracking-widest">Company</th>
              <th className="px-6 py-4 text-[9px] font-black text-gray-500 uppercase tracking-widest">Product</th>
              <th className="px-6 py-4 text-[9px] font-black text-gray-500 uppercase tracking-widest">Quantity</th>
              <th className="px-6 py-4 text-[9px] font-black text-gray-500 uppercase tracking-widest">Remaining</th>
              <th className="px-6 py-4 text-[9px] font-black text-gray-500 uppercase tracking-widest">Match</th>
              <th className="px-6 py-4 text-[9px] font-black text-gray-500 uppercase tracking-widest">Value</th>
              <th className="px-6 py-4 text-[9px] font-black text-gray-500 uppercase tracking-widest">Escrow</th>
              <th className="px-6 py-4 text-[9px] font-black text-gray-500 uppercase tracking-widest text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-brand-border/10">
            {mockRFQs.map((rfq) => (
              <tr 
                key={rfq.id} 
                className="group hover:bg-white/[0.03] transition-all cursor-default even:bg-white/[0.01]"
              >
                <td className="px-6 py-4">
                  <div className="flex items-center gap-3">
                    <span className="text-lg">{rfq.flag}</span>
                    <span className="text-[13px] font-bold text-white group-hover:text-gold transition-colors">{rfq.company}</span>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <span className="text-[11px] font-medium text-gray-400">{rfq.product}</span>
                </td>
                <td className="px-6 py-4">
                  <span className="text-[11px] font-mono font-bold text-white">{rfq.quantity}</span>
                </td>
                <td className="px-6 py-4">
                  <div className="flex flex-col gap-1 w-32">
                    <CountdownTimer endTime={rfq.expiresAt} className="text-[11px]" />
                    <ProgressBar 
                      value={65} 
                      color={rfq.expiresAt.getTime() - Date.now() < 3600000 ? 'error' : 'teal'} 
                    />
                  </div>
                </td>
                <td className="px-6 py-4">
                  <span className={cn(
                    "text-[11px] font-black",
                    rfq.matchPercent > 50 ? "text-success" : rfq.matchPercent > 30 ? "text-gold" : "text-gray-500"
                  )}>
                    {rfq.matchPercent}%
                  </span>
                </td>
                <td className="px-6 py-4">
                  <span className="text-[11px] font-mono font-bold text-white">{rfq.value}</span>
                </td>
                <td className="px-6 py-4">
                  <div className="flex items-center gap-1.5 text-[10px] text-teal font-black uppercase tracking-tighter">
                    <span className="material-icons text-[12px]">account_balance_wallet</span>
                    @{rfq.escrowTime}
                  </div>
                </td>
                <td className="px-6 py-4 text-right">
                  <button className="px-3 py-1.5 rounded-lg bg-gold/5 border border-gold/20 text-gold text-[10px] font-black uppercase tracking-widest hover:bg-gold/10 transition-all">
                    Respond
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default LiveRFQsTable;
