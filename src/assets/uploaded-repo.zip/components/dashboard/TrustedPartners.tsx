
import React from 'react';
import { formatCurrency, cn } from '../../utils';
import Badge from '../ui/Badge';

interface Partner {
  id: string;
  name: string;
  tier: 'gold' | 'silver';
  revenue: number;
  product: string;
  status: string;
  price: number;
  logo: string;
}

const partners: Partner[] = [
  {
    id: '1',
    name: 'LithiumCorp',
    tier: 'gold',
    revenue: 3750000,
    product: 'Lithium Hydroxide (Battery Grade)',
    status: 'Verified 4.2h response',
    price: 83250,
    logo: 'https://picsum.photos/seed/lithiumcorp/64/64',
  },
  {
    id: '2',
    name: 'EverSource Minerals',
    tier: 'gold',
    revenue: 2910000,
    product: 'Lithium Pyroxide Premium',
    status: 'Verified 12d shipping',
    price: 79100,
    logo: 'https://picsum.photos/seed/eversource/64/64',
  },
  {
    id: '3',
    name: 'Metalistica',
    tier: 'gold',
    revenue: 4150000,
    product: 'Lithium Pyroxide Industrial',
    status: 'Verified Gold Member',
    price: 81400,
    logo: 'https://picsum.photos/seed/metalistica/64/64',
  }
];

const TrustedPartners: React.FC = () => {
  return (
    <div className="glass rounded-2xl p-6 border border-brand-border/40">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h3 className="text-sm font-black text-white uppercase tracking-[0.2em]">Trusted Partners</h3>
          <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest mt-1">21 Suppliers in Guide</p>
        </div>
        <button className="flex items-center gap-2 px-3 py-1.5 rounded bg-gold/10 border border-gold/30 text-gold text-[10px] font-black uppercase tracking-tighter">
          Gold Verifieds
          <span className="material-icons text-sm">expand_more</span>
        </button>
      </div>

      <div className="space-y-4">
        {partners.map((partner) => (
          <div key={partner.id} className="p-4 rounded-xl bg-white/[0.02] border border-brand-border/20 flex flex-col lg:flex-row justify-between gap-6 group hover:border-gold/30 transition-all">
            {/* Left Section */}
            <div className="flex gap-4">
              <div className="w-12 h-12 rounded-lg overflow-hidden bg-brand-navy border border-brand-border/40 flex-shrink-0 group-hover:border-gold/40">
                <img src={partner.logo} alt={partner.name} className="w-full h-full object-cover grayscale opacity-60 group-hover:grayscale-0 group-hover:opacity-100 transition-all" />
              </div>
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <h4 className="text-sm font-bold text-white group-hover:text-gold transition-colors">{partner.name}</h4>
                  <Badge variant="gold" icon="verified">Gold Verified</Badge>
                </div>
                <p className="text-[10px] font-bold text-gold uppercase tracking-tighter mb-1">
                  {formatCurrency(partner.revenue)} YTD Revenue
                </p>
                <p className="text-[11px] text-gray-400 font-medium">{partner.product}</p>
                <p className="text-[9px] text-gray-600 font-bold uppercase mt-1">{partner.status}</p>
              </div>
            </div>

            {/* Right Section */}
            <div className="flex flex-col sm:flex-row lg:flex-col xl:flex-row items-start sm:items-center lg:items-end xl:items-center gap-4 lg:gap-2 xl:gap-6">
              <div className="lg:text-right">
                <div className="text-lg font-mono font-bold text-white">
                  {formatCurrency(partner.price)} <span className="text-[10px] text-gray-500">MT</span>
                </div>
                <p className="text-[9px] text-success font-black uppercase tracking-tighter">Spot Adjusted Market</p>
              </div>
              <div className="flex gap-2">
                <button className="px-3 py-1.5 rounded bg-brand-navy border border-brand-border text-[9px] font-black text-gray-400 uppercase hover:text-white hover:border-gold transition-all">Hold</button>
                <button className="px-3 py-1.5 rounded bg-brand-navy border border-brand-border text-[9px] font-black text-gray-400 uppercase hover:text-white hover:border-gold transition-all">More Details</button>
                <button className="px-4 py-1.5 rounded bg-gold text-brand-navy text-[9px] font-black uppercase tracking-widest shadow-lg shadow-gold/20 hover:bg-gold-bright transition-all flex items-center gap-1">
                  Escrow <span className="material-icons text-xs">arrow_forward</span>
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      <button className="w-full mt-6 py-3 border border-brand-border/40 rounded-lg text-[10px] font-bold text-gray-500 hover:text-white transition-all uppercase tracking-[0.2em]">
        View Global Directory
      </button>
    </div>
  );
};

export default TrustedPartners;
