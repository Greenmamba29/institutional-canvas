
import React, { useState } from 'react';
import { formatCurrency, cn } from '../../utils';

interface BiddingPanelProps {
  currentBid: number;
  onPlaceBid: (amount: number) => void;
  minIncrementPercent?: number;
  isOutbid?: boolean;
}

const BiddingPanel: React.FC<BiddingPanelProps> = ({ 
  currentBid, 
  onPlaceBid, 
  minIncrementPercent = 1,
  isOutbid = false
}) => {
  const [customBid, setCustomBid] = useState<string>('');
  const minRequired = Math.ceil(currentBid * (1 + minIncrementPercent / 100));

  const handlePlaceBid = (amount: number) => {
    if (amount >= minRequired) {
      onPlaceBid(amount);
      setCustomBid('');
    }
  };

  const quickBids = [
    { label: '+1%', val: Math.ceil(currentBid * 1.01) },
    { label: '+5%', val: Math.ceil(currentBid * 1.05) },
    { label: '+10%', val: Math.ceil(currentBid * 1.10) },
  ];

  return (
    <div className="glass p-6 rounded-2xl border border-brand-border/40 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-1">Minimum Next Bid</p>
          <h4 className="text-2xl font-mono font-bold text-white">{formatCurrency(minRequired)}</h4>
        </div>
        {isOutbid && (
          <div className="flex items-center gap-2 px-3 py-1 rounded bg-error/10 border border-error/30 text-error animate-pulse">
            <span className="material-icons text-sm">warning</span>
            <span className="text-[10px] font-black uppercase tracking-tighter">You've been outbid</span>
          </div>
        )}
      </div>

      <div className="grid grid-cols-3 gap-3">
        {quickBids.map((qb) => (
          <button
            key={qb.label}
            onClick={() => handlePlaceBid(qb.val)}
            className="py-3 px-2 rounded-xl bg-white/5 border border-brand-border/20 text-gray-400 hover:text-white hover:border-gold/50 transition-all flex flex-col items-center gap-1 group"
          >
            <span className="text-[10px] font-black text-gold group-hover:scale-110 transition-transform">{qb.label}</span>
            <span className="text-[11px] font-mono font-bold">{formatCurrency(qb.val)}</span>
          </button>
        ))}
      </div>

      <div className="relative">
        <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 font-mono">$</span>
        <input
          type="number"
          value={customBid}
          onChange={(e) => setCustomBid(e.target.value)}
          placeholder={`Enter amount (min ${minRequired})`}
          className="w-full pl-10 pr-4 py-4 bg-brand-navy border border-brand-border rounded-xl text-white font-mono focus:ring-gold focus:border-gold transition-all"
        />
      </div>

      <button
        disabled={Number(customBid) < minRequired && !customBid}
        onClick={() => handlePlaceBid(Number(customBid))}
        className={cn(
          "w-full py-4 rounded-xl font-black uppercase tracking-[0.2em] text-sm shadow-xl transition-all flex items-center justify-center gap-2",
          Number(customBid) >= minRequired || (!customBid && false)
            ? "bg-gold text-brand-navy hover:bg-gold-bright shadow-gold/20"
            : "bg-white/5 text-gray-600 border border-brand-border cursor-not-allowed"
        )}
      >
        Place Institutional Bid
        <span className="material-icons text-lg">gavel</span>
      </button>

      <p className="text-[9px] text-gray-600 font-medium text-center uppercase tracking-widest leading-relaxed px-4">
        By placing a bid, you agree to the platform's escrow terms. Bids are legally binding and subject to 256-bit hash verification.
      </p>
    </div>
  );
};

export default BiddingPanel;
