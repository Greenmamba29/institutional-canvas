
import React, { useState, useEffect } from 'react';
import { cn } from '../../utils';

interface CountdownTimerProps {
  endTime: Date;
  className?: string;
}

const CountdownTimer: React.FC<CountdownTimerProps> = ({ endTime, className }) => {
  const [timeLeft, setTimeLeft] = useState({ h: 0, m: 0 });

  useEffect(() => {
    const calculateTime = () => {
      const difference = +endTime - +new Date();
      if (difference > 0) {
        setTimeLeft({
          h: Math.floor((difference / (1000 * 60 * 60))),
          m: Math.floor((difference / 1000 / 60) % 60),
        });
      } else {
        setTimeLeft({ h: 0, m: 0 });
      }
    };

    calculateTime();
    const timer = setInterval(calculateTime, 60000); // Update every minute
    return () => clearInterval(timer);
  }, [endTime]);

  const isWarning = timeLeft.h < 1;

  return (
    <div className={cn(
      "font-mono font-bold flex items-center gap-1",
      isWarning ? "text-error" : "text-gray-400",
      className
    )}>
      <span>{timeLeft.h}h</span>
      <span>{timeLeft.m}m</span>
      {isWarning && <span className="material-icons text-[10px] animate-pulse">priority_high</span>}
    </div>
  );
};

export default CountdownTimer;
