
import React from 'react';

const Intelligence: React.FC = () => {
  return (
    <div className="pt-32 pb-24 bg-background-dark min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <header className="max-w-4xl mx-auto text-center mb-24">
           <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-accent/10 border border-accent/20 text-accent text-[10px] font-bold uppercase mb-8">
             <span className="w-2 h-2 rounded-full bg-accent animate-pulse"></span> Intelligence Hub v2.0
           </div>
           <h1 className="text-5xl md:text-7xl font-display font-bold text-white mb-6">Clarity in <span className="text-gold-gradient italic">Complex Sourcing</span></h1>
           <p className="text-lg text-gray-400 leading-relaxed">Leverage advanced machine learning to summarize RFQs, analyze legal contracts, and extract actionable market intelligence.</p>
           <div className="mt-10 flex gap-4 justify-center">
              <button className="bg-primary text-black px-8 py-4 font-bold rounded text-sm uppercase tracking-widest shadow-lg">Access AI Studio</button>
              <button className="text-gray-400 hover:text-white flex items-center gap-2 font-bold text-sm">Watch the Demo <span className="material-icons">play_circle</span></button>
           </div>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-24">
          <div className="bg-card-dark border border-white/5 rounded-xl p-8 hover:border-accent transition-all group">
            <div className="flex items-center gap-4 mb-8">
               <div className="w-10 h-10 bg-accent/10 text-accent rounded flex items-center justify-center border border-accent/20"><span className="material-icons">analytics</span></div>
               <div><h3 className="font-bold text-white">Market Pulse</h3><p className="text-[10px] text-gray-500">Updated 2m ago</p></div>
            </div>
            <div className="space-y-6">
               <div className="flex justify-between items-center"><span className="text-gray-400 text-sm">Carbonate Spot</span><span className="text-green-400 font-bold">$72,450 <span className="material-icons text-[10px]">arrow_upward</span></span></div>
               <div className="flex justify-between items-center"><span className="text-gray-400 text-sm">Hydroxide Spot</span><span className="text-red-400 font-bold">$68,200 <span className="material-icons text-[10px]">arrow_downward</span></span></div>
               <div className="flex justify-between items-center"><span className="text-gray-400 text-sm">Spodumene</span><span className="text-green-400 font-bold">$1,850 <span className="material-symbols-outlined text-[10px]">arrow_upward</span></span></div>
            </div>
          </div>
          <div className="bg-card-dark border border-primary/20 rounded-xl p-8 hover:border-primary transition-all">
             <div className="flex items-center gap-4 mb-8">
               <div className="w-10 h-10 bg-primary/10 text-primary rounded flex items-center justify-center border border-primary/20"><span className="material-icons">shield</span></div>
               <div><h3 className="font-bold text-white">Risk Alerts</h3><p className="text-[10px] text-gray-500">3 active alerts</p></div>
            </div>
            <div className="space-y-4">
               <div className="p-4 bg-white/5 rounded-lg border border-white/5 cursor-pointer hover:bg-white/10 transition-all">
                  <h4 className="text-white text-sm font-bold">Chile Export Delays</h4>
                  <p className="text-xs text-gray-500 mt-1">Port congestion affecting Q1 shipments</p>
               </div>
               <div className="p-4 bg-white/5 rounded-lg border border-white/5 cursor-pointer hover:bg-white/10 transition-all">
                  <h4 className="text-white text-sm font-bold">DRC Regulatory Change</h4>
                  <p className="text-xs text-gray-500 mt-1">New ESG requirements for 2025</p>
               </div>
            </div>
          </div>
          <div className="bg-card-dark border border-white/5 rounded-xl p-8 hover:border-green-500 transition-all">
             <div className="flex items-center gap-4 mb-8">
               <div className="w-10 h-10 bg-green-500/10 text-green-500 rounded flex items-center justify-center border border-green-500/20"><span className="material-icons">track_changes</span></div>
               <div><h3 className="font-bold text-white">Top Deals</h3><p className="text-[10px] text-gray-500">AI-ranked</p></div>
            </div>
            <div className="space-y-4">
               <div className="p-4 bg-white/5 rounded-lg border border-white/5 flex justify-between items-center">
                  <div><h4 className="text-white text-sm font-bold">Ganfeng #2847</h4><p className="text-[10px] text-gray-500">500 MT Hydroxide</p></div>
                  <span className="bg-green-500/20 text-green-400 text-[10px] font-bold px-2 py-0.5 rounded">92% Match</span>
               </div>
               <div className="p-4 bg-white/5 rounded-lg border border-white/5 flex justify-between items-center">
                  <div><h4 className="text-white text-sm font-bold">SQM #1204</h4><p className="text-[10px] text-gray-500">200 MT Carbonate</p></div>
                  <span className="bg-green-500/20 text-green-400 text-[10px] font-bold px-2 py-0.5 rounded">87% Match</span>
               </div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center mb-32">
           <div>
              <div className="flex items-center gap-2 mb-4 text-primary font-bold uppercase tracking-widest text-xs"><span className="material-icons text-sm">article</span> Document Intelligence</div>
              <h2 className="text-3xl font-display font-bold text-white mb-6">Instant Contract Insights</h2>
              <p className="text-gray-400 leading-relaxed mb-8">Upload supply agreements or RFQs. Our engine highlights critical terms, force majeure clauses, and pricing benchmarks against market indices.</p>
              <ul className="space-y-4 text-sm text-gray-300">
                <li className="flex items-center gap-3"><span className="material-icons text-primary text-sm">check_circle</span> Automated Incoterms® validation</li>
                <li className="flex items-center gap-3"><span className="material-icons text-primary text-sm">check_circle</span> Pricing formula benchmarking</li>
                <li className="flex items-center gap-3"><span className="material-icons text-primary text-sm">check_circle</span> Compliance risk detection</li>
              </ul>
           </div>
           <div className="bg-card-dark border border-white/10 rounded p-1 shadow-2xl">
              <div className="bg-black/50 p-8 rounded border border-white/5 h-[400px] overflow-hidden">
                 <div className="flex justify-between items-center mb-6">
                    <div className="flex items-center gap-3">
                       <span className="material-icons text-red-500">picture_as_pdf</span>
                       <div><h4 className="text-sm font-bold text-white">Supply_Agreement_v4.pdf</h4><p className="text-[10px] text-gray-500">Processed in 1.2s</p></div>
                    </div>
                    <span className="bg-green-500/10 text-green-400 text-[10px] font-bold px-2 py-1 rounded">Active Analysis</span>
                 </div>
                 <div className="space-y-4 opacity-50 select-none blur-[1px]">
                    <div className="h-2 w-3/4 bg-white/20 rounded"></div>
                    <div className="h-2 w-full bg-white/20 rounded"></div>
                    <div className="h-2 w-5/6 bg-white/20 rounded"></div>
                 </div>
                 <div className="mt-8 space-y-4 relative">
                    <div className="p-4 bg-primary/10 border-l-2 border-primary rounded-r">
                       <div className="flex justify-between text-[10px] font-bold text-primary uppercase mb-1"><span>Price Mechanism</span> <span>Pg 4</span></div>
                       <p className="text-[11px] text-gray-300 leading-snug">Linked to Fastmarkets index minus 2.5% discount.</p>
                    </div>
                    <div className="p-4 bg-red-500/10 border-l-2 border-red-500 rounded-r">
                       <div className="flex justify-between text-[10px] font-bold text-red-500 uppercase mb-1"><span>Risk Flag</span> <span>Pg 12</span></div>
                       <p className="text-[11px] text-gray-300 leading-snug">Delivery delay penalty exceeds standard industry caps.</p>
                    </div>
                 </div>
              </div>
           </div>
        </div>
      </div>
    </div>
  );
};

export default Intelligence;
