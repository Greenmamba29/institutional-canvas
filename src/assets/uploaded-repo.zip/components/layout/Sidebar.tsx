
import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { cn } from '../../utils';
import MissionControl from './MissionControl';

interface NavItem {
  label: string;
  icon: string;
  path: string;
  badge?: string;
  hasSubmenu?: boolean;
}

const Sidebar: React.FC = () => {
  const location = useLocation();
  const [expandedItems, setExpandedItems] = useState<Record<string, boolean>>({
    Overview: true,
    Settings: false
  });

  const isActive = (path: string) => location.pathname === path;

  const navItems: NavItem[] = [
    { label: 'Dashboard', icon: 'home', path: '/dashboard' },
    { label: 'Overview', icon: 'grid_view', path: '/overview', hasSubmenu: true },
    { label: 'RFQs', icon: 'description', path: '/rfqs', badge: '8' },
    { label: 'Auctions', icon: 'gavel', path: '/auctions', badge: '14' },
    { label: 'Orders', icon: 'shopping_cart', path: '/orders', badge: '3' },
    { label: 'Verification', icon: 'verified_user', path: '/trust', badge: '5' },
    { label: 'Analytics', icon: 'analytics', path: '/analytics' },
    { label: 'Audit Log', icon: 'history', path: '/audit' },
    { label: 'Directory', icon: 'contacts', path: '/directory' },
    { label: 'Messages', icon: 'mail_outline', path: '/messages', badge: '12' },
    { label: 'Settings', icon: 'settings', path: '/settings', hasSubmenu: true },
    { label: 'Help Center', icon: 'help_outline', path: '/help' },
  ];

  const toggleExpand = (label: string) => {
    setExpandedItems(prev => ({ ...prev, [label]: !prev[label] }));
  };

  return (
    <aside className="fixed left-0 top-0 h-full w-[260px] glass border-r border-brand-border z-40 hidden lg:flex flex-col pt-16">
      <nav className="flex-1 px-4 py-6 space-y-1 overflow-y-auto overflow-x-hidden custom-scrollbar">
        {navItems.map((item) => (
          <div key={item.label}>
            <div className="relative">
              <Link
                to={item.path}
                onClick={(e) => {
                  if (item.hasSubmenu) {
                    e.preventDefault();
                    toggleExpand(item.label);
                  }
                }}
                className={cn(
                  "flex items-center justify-between px-3 py-2.5 rounded-lg transition-all group relative overflow-hidden",
                  isActive(item.path)
                    ? "text-white bg-teal/5 border-l-2 border-teal shadow-[inset_10px_0_15px_-10px_rgba(14,165,233,0.3)]"
                    : "text-gray-400 hover:text-white hover:bg-white/5"
                )}
              >
                {/* Hover Glow Effect */}
                <div className="absolute inset-0 bg-teal/5 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                
                <div className="flex items-center gap-3 relative z-10">
                  <span className={cn(
                    "material-icons text-[20px]",
                    isActive(item.path) ? "text-teal" : "text-gray-500 group-hover:text-gray-300"
                  )}>
                    {item.icon}
                  </span>
                  <span className="text-[13px] font-semibold tracking-wide">
                    {item.label}
                  </span>
                </div>

                <div className="flex items-center gap-2 relative z-10">
                  {item.badge && (
                    <span className={cn(
                      "text-[9px] font-black px-1.5 py-0.5 rounded min-w-[18px] text-center",
                      item.label === 'RFQs' || item.label === 'Auctions' 
                        ? "bg-gold/20 text-gold" 
                        : "bg-teal/20 text-teal"
                    )}>
                      {item.badge}
                    </span>
                  )}
                  {item.hasSubmenu && (
                    <span className={cn(
                      "material-icons text-sm transition-transform duration-200",
                      expandedItems[item.label] ? "rotate-180" : ""
                    )}>
                      expand_more
                    </span>
                  )}
                </div>
              </Link>
            </div>

            {/* Submenu Expansion */}
            {item.hasSubmenu && expandedItems[item.label] && (
              <div className="mt-1 ml-9 space-y-1 border-l border-brand-border">
                {['Sub Item A', 'Sub Item B'].map(sub => (
                  <button key={sub} className="w-full text-left px-4 py-1.5 text-[11px] text-gray-500 hover:text-teal transition-colors font-medium">
                    {sub}
                  </button>
                ))}
              </div>
            )}
          </div>
        ))}
      </nav>

      {/* Footer Metrics */}
      <MissionControl />
    </aside>
  );
};

export default Sidebar;
