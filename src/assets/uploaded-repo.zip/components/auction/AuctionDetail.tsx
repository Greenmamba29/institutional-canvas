
import React, { useState, useEffect } from 'react';
import { formatCurrency, cn } from '../../utils';
import BiddingPanel from './BiddingPanel';
import BidHistory, { Bid } from './BidHistory';
import VerificationBadge from '../ui/VerificationBadge';

interface AuctionDetailProps {
  id: string;
  material: string;
  supplier: string;
  initialBid: number;
  lotSize: string;
  purity: string;
  origin: string;
  onClose?: () => void;
}

const AuctionDetail: React.FC<AuctionDetailProps> = ({
  id,
  material,
  supplier,
  initialBid,
  lotSize,
  purity,
  origin,
  onClose
}) => {
  const [currentBid, setCurrentBid] = useState(initialBid);
  const [bids, setBids] = useState<Bid[]>([
    { id: 'h1', bidderName: 'Bidder #104', amount: initialBid * 0.95, timestamp: new Date(Date.now() - 3600000) },
    { id: 'h2', bidderName: 'Institutional Source', amount: initialBid * 0.98, timestamp: new Date(Date.now() - 1800000) },
    { id: 'h3', bidderName: 'Verified Fund', amount: initialBid, timestamp: new Date(Date.now() - 300000) },
  ]);
  const [isOutbid, setIsOutbid] = useState(false);
  const [isUpdating, setIsUpdating] = useState(false);

  // Simulate other bidders
  useEffect(() => {
    const timer = setInterval(() => {
      if (Math.random() > 0.85) { // 15% chance of a new bot bid every 10s
        const increment = Math.ceil(currentBid * 0.012);
        const newAmount = currentBid + increment;
        
        setIsUpdating(true);
        setTimeout(() => {
          setCurrentBid(newAmount);
          const newBid: Bid = {
            id: Date.now().toString(),
            bidderName: `Source #${Math.floor(Math.random() * 900) + 100}`,
            amount: newAmount,
            timestamp: new Date()
          };
          setBids(prev => [...prev, newBid]);
          setIsOutbid(true);
          setIsUpdating(false);
        }, 500);
      }
    }, 10000);

    return () => clearInterval(timer);
  }, [currentBid]);

  const handleUserBid = (amount: number) => {
    setIsUpdating(true);
    setTimeout(() => {
      setCurrentBid(amount);
      const userBid: Bid = {
        id: Date.now().toString(),
        bidderName: 'You',
        amount: amount,
        timestamp: new Date(),
        isUser: true
      };
      setBids(prev => [...prev, userBid]);
      setIsOutbid(false);
      setIsUpdating(false);
    }, 400);
  };

  return (
    <div className="flex flex-col xl:flex-row gap-8 animate-fade-in pb-20">
      {/* Left Column: Lot Info & Bidding */}
      <div className="xl:col-span-8 flex-1 space-y-8">
        <div className="glass rounded-2xl border border-brand-border/40 p-8 relative overflow-hidden">
          {/* Visual Accents */}
          <div className="absolute top-0 right-0 w-32 h-32 bg-gold/5 blur-[50px] rounded-full"></div>
          
          <div className="relative z-10">
            <div className="flex justify-between items-start mb-10">
              <div>
                <div className="flex items-center gap-3 mb-2">
                  <span className="text-[10px] font-black text-gold bg-gold/10 border border-gold/30 px-2 py-0.5 rounded uppercase tracking-[0.2em]">Active Lot #{id}</span>
                  <VerificationBadge tier="gold" />
                </div>
                <h2 className="text-3xl font-display font-bold text-white mb-1">{material}</h2>
                <p className="text-gray-500 font-bold uppercase text-[11px] tracking-widest">{supplier}</p>
              </div>
              <div className="text-right">
                <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-1">Lot Current Price</p>
                <div className={cn(
                  "text-4xl font-mono font-bold transition-all duration-500",
                  isUpdating ? "text-gold scale-105" : "text-white"
                )}>
                  {formatCurrency(currentBid)}
                </div>
                <p className="text-[11px] text-success font-black uppercase mt-1 flex items-center justify-end gap-1">
                  <span className="material-icons text-xs">trending_up</span>
                  High Liquidity Zone
                </p>
              </div>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-8 py-8 border-y border-brand-border/20">
              <div>
                <p className="text-[9px] font-bold text-gray-500 uppercase tracking-widest mb-1">Quantity</p>
                <p className="text-lg font-mono font-bold text-white">{lotSize}</p>
              </div>
              <div>
                <p className="text-[9px] font-bold text-gray-500 uppercase tracking-widest mb-1">Purity Grade</p>
                <p className="text-lg font-mono font-bold text-teal">{purity}</p>
              </div>
              <div>
                <p className="text-[9px] font-bold text-gray-500 uppercase tracking-widest mb-1">Origin</p>
                <p className="text-lg font-bold text-white flex items-center gap-2">
                  <span className="w-5 h-3 bg-red-600 rounded-sm"></span>
                  {origin}
                </p>
              </div>
              <div>
                <p className="text-[9px] font-bold text-gray-500 uppercase tracking-widest mb-1">Est. Value</p>
                <p className="text-lg font-mono font-bold text-gold">{formatCurrency(currentBid * 20)}</p>
              </div>
            </div>

            <div className="mt-8 flex justify-between items-center bg-white/[0.02] p-4 rounded-xl border border-brand-border/20">
               <div className="flex items-center gap-4">
                 <div className="w-10 h-10 rounded-full border border-teal/30 bg-teal/5 flex items-center justify-center">
                   <span className="material-icons text-teal text-xl">verified</span>
                 </div>
                 <div>
                    <p className="text-[11px] font-bold text-white">LME Grade A Authenticated</p>
                    <p className="text-[9px] text-gray-500 uppercase tracking-tighter">Verified by Bureau Veritas 2024</p>
                 </div>
               </div>
               <button className="text-[10px] font-black text-teal uppercase hover:underline tracking-widest">View Certification Hub →</button>
            </div>
          </div>
        </div>

        <BiddingPanel 
          currentBid={currentBid} 
          onPlaceBid={handleUserBid} 
          isOutbid={isOutbid}
        />
      </div>

      {/* Right Column: Live History */}
      <div className="xl:col-span-4 w-full xl:w-[400px]">
        <BidHistory bids={bids} className="h-[650px]" />
      </div>
    </div>
  );
};

export default AuctionDetail;
