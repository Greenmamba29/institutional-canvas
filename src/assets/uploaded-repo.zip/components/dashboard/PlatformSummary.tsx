
import React from 'react';
import { formatCurrency, formatNumber } from '../../utils';

const PlatformSummary: React.FC = () => {
  return (
    <div className="glass p-6 rounded-xl border border-brand-border/60 bg-gradient-to-br from-brand-panel/40 to-brand-navy/60 h-full flex flex-col justify-between">
      <div>
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-[11px] font-black text-gray-500 uppercase tracking-[0.2em]">Platform Summary</h3>
          <div className="flex items-center gap-1 bg-gold/10 border border-gold/30 px-2 py-1 rounded">
            <span className="text-[10px] font-black text-gold uppercase tracking-tighter">4% +1 FEE RATE</span>
          </div>
        </div>

        <div className="mb-8">
          <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-1">Total Marketplace Value</p>
          <div className="text-3xl font-mono font-bold text-white tracking-tighter">
            {formatCurrency(16207430)}
          </div>
        </div>
      </div>

      <div className="pt-6 border-t border-brand-border/40 space-y-4">
        <div className="flex justify-between items-center">
          <div>
            <p className="text-[9px] font-bold text-gray-500 uppercase tracking-widest">Auction Fees</p>
            <p className="text-lg font-mono font-bold text-white">{formatCurrency(608297)}</p>
          </div>
          <div className="text-right">
            <div className="flex items-center justify-end gap-1 text-[10px] font-bold text-success uppercase">
              <span className="material-icons text-xs">north</span>
              2.4%
            </div>
            <p className="text-[8px] text-gray-600 font-bold uppercase mt-1">Growth Index</p>
          </div>
        </div>

        <div className="h-1.5 w-full bg-white/5 rounded-full overflow-hidden">
          <div className="h-full bg-teal w-3/4 rounded-full shadow-[0_0_10px_rgba(14,165,233,0.3)]"></div>
        </div>
      </div>
    </div>
  );
};

export default PlatformSummary;
