
import React from 'react';
import { SupplierProfile } from '../../types';
import VerificationBadge, { VerificationTier } from '../ui/VerificationBadge';
import { formatCurrency, cn } from '../../utils';

interface SupplierCardProps {
  supplier: SupplierProfile;
  onClick: (id: string) => void;
}

const SupplierCard: React.FC<SupplierCardProps> = ({ supplier, onClick }) => {
  return (
    <div 
      onClick={() => onClick(supplier.id)}
      className="glass p-1 rounded-2xl hover:border-gold/40 transition-all duration-300 group cursor-pointer h-full"
    >
      <div className="bg-white/[0.02] rounded-xl p-6 h-full flex flex-col">
        <div className="flex justify-between items-start mb-6">
          <div className="w-16 h-16 rounded-xl bg-brand-navy border border-brand-border/40 p-3 group-hover:border-gold/50 transition-colors">
            <img 
              src={supplier.logoUrl} 
              alt={supplier.name} 
              className="w-full h-full object-contain grayscale group-hover:grayscale-0 transition-all opacity-60 group-hover:opacity-100" 
            />
          </div>
          <VerificationBadge tier={supplier.verificationTier.toLowerCase() as VerificationTier} />
        </div>

        <div className="mb-6 flex-grow">
          <h3 className="text-xl font-bold text-white group-hover:text-gold transition-colors mb-1">{supplier.name}</h3>
          <p className="text-xs text-gray-500 font-bold uppercase tracking-widest flex items-center gap-1">
            <span className="material-icons text-xs text-gold">location_on</span>
            {supplier.region}
          </p>
        </div>

        <div className="grid grid-cols-2 gap-4 mb-6 py-4 border-y border-brand-border/10">
          <div>
            <p className="text-[9px] font-bold text-gray-500 uppercase tracking-widest mb-1">Trust Score</p>
            <div className="flex items-center gap-2">
              <div className="flex-1 h-1 bg-white/5 rounded-full overflow-hidden">
                <div 
                  className="h-full bg-teal shadow-[0_0_8px_rgba(14,165,233,0.5)]" 
                  style={{ width: `${supplier.trustScore}%` }}
                ></div>
              </div>
              <span className="text-xs font-mono font-bold text-white">{supplier.trustScore}</span>
            </div>
          </div>
          <div>
            <p className="text-[9px] font-bold text-gray-500 uppercase tracking-widest mb-1">Purity Grade</p>
            <p className="text-sm font-mono font-bold text-teal">{supplier.purityRating}%</p>
          </div>
        </div>

        <div className="flex flex-col gap-2 mt-auto">
          <button className="w-full py-2.5 bg-gold text-brand-navy font-black text-[10px] uppercase tracking-widest rounded-lg hover:bg-gold-bright transition-all">
            View Full Profile
          </button>
          <button className="w-full py-2.5 border border-brand-border/40 text-gray-400 font-black text-[10px] uppercase tracking-widest rounded-lg hover:text-white hover:border-white transition-all">
            Contact Direct
          </button>
        </div>
      </div>
    </div>
  );
};

export default SupplierCard;
