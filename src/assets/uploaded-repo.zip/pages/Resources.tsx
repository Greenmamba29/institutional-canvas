
import React from 'react';

const Resources: React.FC = () => {
  return (
    <div className="pt-32 pb-24 bg-background-dark min-h-screen relative overflow-hidden">
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-full h-[600px] bg-primary/5 blur-[120px] rounded-full pointer-events-none"></div>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center mb-20">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 border border-primary/20 text-primary text-[10px] font-bold uppercase mb-8">
            <span className="w-2 h-2 rounded-full bg-primary animate-pulse"></span> Intelligence Center
          </div>
          <h1 className="text-5xl md:text-6xl font-display font-bold text-white mb-6 leading-tight">Powering decisions with <br /><span className="text-gold-gradient italic">Global Lithium Insights</span></h1>
          <p className="max-w-2xl mx-auto text-lg text-gray-400 mb-10">Access tier-1 market analysis, sustainability frameworks, and developer tools designed for enterprise-grade sourcing.</p>
          <div className="max-w-3xl mx-auto bg-card-dark border border-white/5 p-2 rounded-lg shadow-2xl flex flex-col md:flex-row gap-2">
            <input type="text" placeholder="Search reports, API docs, or guides..." className="flex-grow bg-transparent border-none text-white focus:ring-0 placeholder-gray-500 text-sm px-4" />
            <div className="flex gap-2">
              <select className="bg-white/5 border-none text-gray-400 rounded text-xs px-4 py-2">
                <option>All Resources</option>
                <option>Market Reports</option>
                <option>Sustainability</option>
              </select>
              <button className="bg-primary text-black font-bold px-6 py-2.5 rounded text-sm transition-colors">Find</button>
            </div>
          </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <div className="col-span-1 md:col-span-2 lg:col-span-2 bg-card-dark border border-white/5 rounded-2xl p-10 hover:border-primary/20 transition-all flex flex-col justify-between group">
             <div className="flex items-center gap-3 mb-6">
                <span className="bg-primary/20 text-primary text-[10px] font-bold px-2 py-1 rounded border border-primary/20">FEATURED REPORT</span>
                <span className="text-gray-500 text-xs">5 min read</span>
             </div>
             <div>
                <h3 className="text-3xl font-display font-bold text-white mb-4 group-hover:text-primary transition-colors">Global Lithium Price Index: 2024 Forecast</h3>
                <p className="text-gray-400 max-w-xl leading-relaxed mb-8">A comprehensive analysis of supply constraints, EV demand fluctuations across APAC and EMEA, and the impact of new extraction technologies on spot pricing.</p>
             </div>
             <div className="flex items-center gap-4">
               <button className="text-primary font-bold flex items-center gap-2 group-hover:gap-3 transition-all">Read Report <span className="material-icons text-sm">arrow_forward</span></button>
               <span className="text-gray-600 text-xs">— By Sarah Edwards, Senior Analyst</span>
             </div>
          </div>
          <div className="bg-gradient-to-br from-card-dark to-[#0D1016] border border-white/5 rounded-2xl p-8 hover:border-primary/30 transition-all flex flex-col h-full">
             <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center mb-6 text-primary"><span className="material-icons">psychology</span></div>
             <h3 className="text-xl font-bold text-white mb-3">AI Sourcing Studio</h3>
             <p className="text-sm text-gray-500 mb-8 leading-relaxed">Learn how to leverage our generative AI to match with suppliers based on chemical purity and logistical constraints.</p>
             <button className="mt-auto w-full py-3 border border-white/10 rounded text-xs font-bold uppercase hover:bg-white/5 transition-all text-gray-300">Launch Guide</button>
          </div>
          {[
            { icon: 'eco', title: 'ESG Compliance Framework', color: 'text-green-400', desc: 'Standardizing carbon footprint reporting for lithium extraction.' },
            { icon: 'integration_instructions', title: 'Developer API Docs', color: 'text-purple-400', desc: 'Integrate real-time pricing and inventory data into your ERP.' },
            { icon: 'gavel', title: 'Contract Templates', color: 'text-orange-400', desc: 'Standardized purchasing agreements and NDA templates.' },
          ].map((item, i) => (
            <div key={i} className="bg-card-dark border border-white/5 rounded-2xl p-8 hover:border-white/10 transition-all group">
               <div className="flex justify-between items-start mb-6">
                  <div className={`w-12 h-12 bg-white/5 rounded-lg flex items-center justify-center ${item.color}`}><span className="material-icons text-2xl">{item.icon}</span></div>
                  <span className="material-icons text-gray-600 group-hover:text-white transition-colors cursor-pointer">bookmark_border</span>
               </div>
               <h3 className="text-xl font-bold text-white mb-3">{item.title}</h3>
               <p className="text-sm text-gray-500 mb-6">{item.desc}</p>
               <button className="text-xs font-bold text-gray-400 hover:text-white flex items-center gap-2 transition-colors">Access Library <span className="material-icons text-xs">arrow_forward</span></button>
            </div>
          ))}
        </div>

        <div className="mt-20 bg-card-dark rounded-2xl border border-white/5 p-12 text-center">
            <h2 className="text-2xl font-display font-bold text-white mb-4 tracking-wide">Weekly Supply Chain Brief</h2>
            <p className="text-gray-400 mb-10 max-w-xl mx-auto">Join 15,000+ industry leaders receiving our weekly digest on lithium pricing, regulatory changes, and supplier verification updates.</p>
            <form className="max-w-md mx-auto flex gap-2">
               <input type="email" placeholder="Enter work email" className="flex-grow bg-black border border-white/10 rounded px-4 py-3 text-sm text-white focus:ring-primary focus:border-primary" />
               <button className="bg-white text-black font-bold px-8 py-3 rounded text-sm hover:bg-gray-200 transition-colors">Subscribe</button>
            </form>
        </div>
      </div>
    </div>
  );
};

export default Resources;
