
import React, { useState } from 'react';
import { SupplierProfile } from '../../types';
import SupplierCard from './SupplierCard';
import SupplierListItem from './SupplierListItem';
import { cn } from '../../utils';

interface DirectoryGridProps {
  suppliers: SupplierProfile[];
  onSupplierClick: (id: string) => void;
}

const DirectoryGrid: React.FC<DirectoryGridProps> = ({ suppliers, onSupplierClick }) => {
  const [view, setView] = useState<'grid' | 'list'>('grid');

  return (
    <div className="flex-1 space-y-6">
      {/* List Header / View Switcher */}
      <div className="glass p-4 rounded-xl flex flex-col md:flex-row gap-6 items-center justify-between border border-brand-border/40">
        <div className="flex items-center gap-4">
          <p className="text-sm font-bold text-white">
            <span className="text-gold font-mono">{suppliers.length}</span> Verified Suppliers Found
          </p>
          <div className="h-4 w-px bg-brand-border/40" />
          <div className="flex gap-1 bg-brand-navy p-1 rounded-lg border border-brand-border/20">
            <button 
              onClick={() => setView('grid')}
              className={cn(
                "p-1.5 rounded transition-all",
                view === 'grid' ? "bg-white/10 text-white" : "text-gray-600 hover:text-gray-400"
              )}
            >
              <span className="material-icons text-base">grid_view</span>
            </button>
            <button 
              onClick={() => setView('list')}
              className={cn(
                "p-1.5 rounded transition-all",
                view === 'list' ? "bg-white/10 text-white" : "text-gray-600 hover:text-gray-400"
              )}
            >
              <span className="material-icons text-base">list</span>
            </button>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <span className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">Sort By:</span>
          <select className="bg-transparent border-none text-xs font-bold text-teal focus:ring-0 cursor-pointer uppercase tracking-wider">
            <option value="rating">Trust Score</option>
            <option value="sales">Sales Volume</option>
            <option value="response">Response Time</option>
          </select>
        </div>
      </div>

      {suppliers.length === 0 ? (
        <div className="glass rounded-2xl border border-brand-border/40 p-20 text-center">
           <span className="material-icons text-6xl text-brand-border/40 mb-4">search_off</span>
           <h3 className="text-xl font-bold text-white mb-2">No matching suppliers found</h3>
           <p className="text-gray-500 text-sm">Adjust your filters or try a broader search term.</p>
        </div>
      ) : view === 'grid' ? (
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
          {suppliers.map(s => (
            <SupplierCard key={s.id} supplier={s} onClick={onSupplierClick} />
          ))}
        </div>
      ) : (
        <div className="flex flex-col gap-4">
          {suppliers.map(s => (
            <SupplierListItem key={s.id} supplier={s} onClick={onSupplierClick} />
          ))}
        </div>
      )}
    </div>
  );
};

export default DirectoryGrid;
