
import React from 'react';

const About: React.FC = () => {
  return (
    <div className="pt-32 pb-24 bg-background-dark min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <header className="text-center mb-24">
           <span className="inline-block py-1 px-3 rounded-full bg-primary/10 border border-primary/20 text-primary text-[10px] font-bold uppercase mb-6 tracking-widest">Architects of the Energy Transition</span>
           <h1 className="text-5xl md:text-7xl font-display font-bold text-white mb-8">Redefining <span className="text-gold-gradient italic">Market Integrity</span></h1>
           <p className="max-w-3xl mx-auto text-xl text-gray-300 font-light leading-relaxed">Lithium & Lux bridges the gap between verified tier-1 suppliers and global enterprise demand, securing the supply chain for an electrified future.</p>
        </header>

        <section className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center mb-32">
           <div className="space-y-8">
              <div>
                <h2 className="text-sm font-bold text-primary tracking-widest uppercase mb-4">Our Vision</h2>
                <h3 className="text-3xl font-display font-bold text-white mb-6">Securing the Essential Elements</h3>
                <p className="text-gray-400 leading-relaxed mb-6">In a volatile global market, trust is the most valuable commodity. We built a secure digital fortress for high-value transaction settlement, ensuring transparency where it matters most.</p>
                <p className="text-gray-400 leading-relaxed">Our proprietary verification protocols ensure that every ounce of lithium traded on our platform meets the rigorous purity standards required by next-gen battery technologies.</p>
              </div>
              <div className="grid grid-cols-2 gap-8 border-t border-white/10 pt-8">
                 <div>
                    <div className="text-3xl font-cinzel font-bold text-white">$2.4B+</div>
                    <div className="text-[10px] text-gray-500 uppercase tracking-widest mt-1">Transaction Volume</div>
                 </div>
                 <div>
                    <div className="text-3xl font-cinzel font-bold text-white">99.9%</div>
                    <div className="text-[10px] text-gray-500 uppercase tracking-widest mt-1">Purity Verification</div>
                 </div>
              </div>
           </div>
           <div className="relative aspect-square rounded-2xl overflow-hidden border border-white/10 shadow-2xl">
              <img src="https://images.unsplash.com/photo-1516321318423-f06f85e504b3?q=80&w=2832&auto=format&fit=crop" className="w-full h-full object-cover grayscale opacity-50" alt="Tech" />
              <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent"></div>
              <div className="absolute bottom-8 left-8 right-8 bg-card-dark/95 p-6 rounded border border-white/10">
                 <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-bold text-white flex items-center gap-2"><span className="material-icons text-primary text-sm">verified_user</span> Escrow Secured</span>
                    <span className="text-[10px] text-accent font-bold uppercase tracking-widest flex items-center animate-pulse"><span className="w-1.5 h-1.5 rounded-full bg-accent mr-1.5"></span> Live</span>
                 </div>
                 <div className="h-1 bg-gray-800 rounded-full overflow-hidden"><div className="h-full bg-primary w-3/4"></div></div>
              </div>
           </div>
        </section>

        <section className="mb-32">
           <h2 className="text-3xl font-display font-bold text-white text-center mb-16">Global Strategic Presence</h2>
           <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[
                { city: 'Geneva, Switzerland', role: 'Headquarters', desc: 'Centering our financial operations and compliance teams in the heart of global trading.' },
                { city: 'Perth, Australia', role: 'Supply Hub', desc: 'Direct on-ground auditing teams working with extraction sites to guarantee source authenticity.' },
                { city: 'Shanghai, China', role: 'Logistics Center', desc: 'Managing downstream processing partnerships and facilitating rapid export logistics.' },
              ].map((loc, i) => (
                <div key={i} className="bg-card-dark p-8 border border-white/5 rounded hover:border-primary/50 transition-all">
                   <div className="w-10 h-10 bg-primary/10 text-primary flex items-center justify-center rounded-full mb-6"><span className="material-icons">hub</span></div>
                   <h4 className="text-xl font-display font-bold text-white mb-2">{loc.city}</h4>
                   <p className="text-[10px] text-gray-500 uppercase font-bold tracking-widest mb-4">{loc.role}</p>
                   <p className="text-sm text-gray-400 leading-relaxed">{loc.desc}</p>
                </div>
              ))}
           </div>
        </section>

        <section>
           <h2 className="text-3xl font-display font-bold text-white mb-12">Leadership Council</h2>
           <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
              {[
                { name: 'Alexander Vane', role: 'Chief Executive Officer', bio: 'Former Head of Commodities at Zenith Capital.' },
                { name: 'Dr. Sarah Chen', role: 'Head of Geology', bio: 'PhD in Mineralogy. Expert in lithium brine extraction.' },
                { name: 'Marcus Thorne', role: 'Director of Trade', bio: 'Specialist in cross-border logistics and Asian markets.' },
                { name: 'Elena Rostova', role: 'Chief Legal Officer', bio: 'Expert in international maritime law and arbitration.' },
              ].map((person, i) => (
                <div key={i} className="bg-card-dark p-6 border border-white/5 hover:border-primary/30 transition-all group">
                   <div className="w-16 h-16 rounded-full bg-gray-800 mb-6 overflow-hidden border border-white/10">
                      <img src={`https://picsum.photos/seed/${person.name}/64/64`} alt={person.name} className="grayscale group-hover:grayscale-0 transition-all" />
                   </div>
                   <h3 className="text-lg font-bold text-white">{person.name}</h3>
                   <p className="text-[10px] text-primary font-bold uppercase tracking-widest mt-1 mb-4">{person.role}</p>
                   <p className="text-xs text-gray-500 leading-relaxed">{person.bio}</p>
                </div>
              ))}
           </div>
        </section>
      </div>
    </div>
  );
};

export default About;
