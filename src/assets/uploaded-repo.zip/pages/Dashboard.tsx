
import React from 'react';
import AppLayout from '../components/layout/AppLayout';
import OverviewHeader from '../components/dashboard/OverviewHeader';
import DailyGMVChart from '../components/dashboard/DailyGMVChart';
import MetricsReview from '../components/dashboard/MetricsReview';
import TrustedPartners from '../components/dashboard/TrustedPartners';
import AuditLog from '../components/dashboard/AuditLog';
import { cn } from '../utils';

const Dashboard: React.FC = () => {
  return (
    <AppLayout>
      <div className="space-y-10 pb-12">
        {/* Main Header Stats Row */}
        <section>
          <OverviewHeader />
        </section>

        {/* Charts and Data Density Section */}
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-8">
          <div className="xl:col-span-8">
            <DailyGMVChart />
            
            {/* System Performance Sub-row */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-8">
              <div className="glass p-6 rounded-2xl border border-brand-border/40 flex items-center gap-6 group hover:border-gold/30 transition-all cursor-pointer">
                <div className="w-16 h-16 rounded-2xl bg-gold/5 flex items-center justify-center border border-gold/20 group-hover:bg-gold/10 transition-colors">
                  <span className="material-icons text-3xl text-gold">analytics</span>
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white">Advanced Sourcing Analytics</h4>
                  <p className="text-xs text-gray-500 mt-1">Deep-dive into regional supply chain constraints and purity benchmarks.</p>
                </div>
              </div>
              <div className="glass p-6 rounded-2xl border border-brand-border/40 flex items-center gap-6 group hover:border-teal/30 transition-all cursor-pointer">
                <div className="w-16 h-16 rounded-2xl bg-teal/5 flex items-center justify-center border border-teal/20 group-hover:bg-teal/10 transition-colors">
                  <span className="material-icons text-3xl text-teal">verified</span>
                </div>
                <div>
                  <h4 className="text-sm font-bold text-white">Verification Pipeline</h4>
                  <p className="text-xs text-gray-500 mt-1">Status of ongoing KYB/KYC audits for 14 new institutional suppliers.</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="xl:col-span-4">
            <MetricsReview />
          </div>
        </div>

        {/* Directory and Activity Section */}
        <div className="grid grid-cols-1 xl:grid-cols-12 gap-8">
          <div className="xl:col-span-8">
            <TrustedPartners />
          </div>
          <div className="xl:col-span-4">
            <AuditLog />
          </div>
        </div>

        {/* Footer Quick Actions */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-10">
          {[
            { label: 'Active RFQs', val: '263', icon: 'description', color: 'text-gold' },
            { label: 'Settled Orders', val: '526', icon: 'check_circle', color: 'text-success' },
            { label: 'Escrow Holdings', val: '$1.8B', icon: 'account_balance', color: 'text-teal' },
            { label: 'Market Alerts', val: '12', icon: 'notifications_active', color: 'text-error' },
          ].map((action, i) => (
            <div key={i} className="glass p-4 rounded-xl border border-brand-border/40 flex items-center gap-4 hover:bg-white/5 transition-all cursor-pointer">
              <span className={cn("material-icons", action.color)}>{action.icon}</span>
              <div>
                <p className="text-[9px] font-bold text-gray-500 uppercase tracking-widest">{action.label}</p>
                <p className="text-sm font-mono font-bold text-white">{action.val}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </AppLayout>
  );
};

export default Dashboard;
