
import React from 'react';
import AppLayout from '../components/layout/AppLayout';

const Architecture: React.FC = () => {
  return (
    <div className="bg-cosmic-radial min-h-screen pt-24 pb-24">
      <div className="max-w-7xl mx-auto px-6">
        <header className="text-center mb-20">
          <div className="inline-flex items-center gap-4 mb-6">
            <div className="w-12 h-[1px] bg-gold"></div>
            <h2 className="text-gold font-mono font-bold tracking-[0.4em] uppercase text-xs">LithiumBuy OS</h2>
            <div className="w-12 h-[1px] bg-gold"></div>
          </div>
          <h1 className="text-5xl md:text-7xl font-display font-bold text-white mb-6">System Architecture</h1>
          <p className="text-gray-400 max-w-2xl mx-auto font-light text-lg italic">The orchestration layer for institutional lithium trading.</p>
        </header>

        {/* System Diagram Representation */}
        <div className="glass rounded-3xl border border-brand-border/40 p-12 mb-20 relative overflow-hidden">
          {/* Animated Background Pulse */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-teal/5 blur-[120px] rounded-full animate-pulse-slow"></div>
          
          <div className="relative z-10 grid grid-cols-1 lg:grid-cols-3 gap-16 items-center">
            {/* Column 1: External Intelligence */}
            <div className="space-y-8">
              <h3 className="text-[10px] font-black text-gray-500 uppercase tracking-widest text-center">External Intelligence</h3>
              <div className="glass p-6 rounded-2xl border-l-4 border-teal flex items-center gap-4">
                <span className="material-icons text-teal">auto_awesome</span>
                <div>
                   <p className="text-sm font-bold text-white">LLM Processing</p>
                   <p className="text-[10px] text-gray-500">Claude / ChatGPT / Perplexity</p>
                </div>
              </div>
              <div className="glass p-6 rounded-2xl border-l-4 border-gold flex items-center gap-4">
                <span className="material-icons text-gold">video_call</span>
                <div>
                   <p className="text-sm font-bold text-white">Video Intelligence</p>
                   <p className="text-[10px] text-gray-500">Zoom / Daily.co Webhooks</p>
                </div>
              </div>
            </div>

            {/* Column 2: Core Data Hub */}
            <div className="flex flex-col items-center">
              <div className="w-48 h-48 rounded-full border-2 border-dashed border-teal/30 flex items-center justify-center relative animate-spin-slow">
                 <div className="absolute inset-0 bg-teal/5 rounded-full blur-xl"></div>
              </div>
              <div className="absolute flex flex-col items-center gap-4">
                 <span className="material-icons text-6xl text-teal drop-shadow-[0_0_15px_rgba(14,165,233,0.5)]">database</span>
                 <h4 className="text-xl font-bold text-white">Supabase Data Hub</h4>
                 <p className="text-[10px] font-black text-teal uppercase tracking-widest">Postgres + RLS Security</p>
              </div>
            </div>

            {/* Column 3: Platform Modules */}
            <div className="space-y-4">
               {[
                 { id: '01', title: 'Marketplace', icon: 'storefront' },
                 { id: '02', title: 'Enterprise Sourcing', icon: 'factory' },
                 { id: '03', title: 'AI Studio', icon: 'psychology' },
                 { id: '04', title: 'TeleBuy Connect', icon: 'terminal' },
               ].map(mod => (
                 <div key={mod.id} className="glass p-4 rounded-xl border border-brand-border/20 flex justify-between items-center group hover:border-gold/30 transition-all cursor-pointer">
                    <div className="flex items-center gap-3">
                       <span className="text-[10px] font-mono text-gold/50">{mod.id}</span>
                       <span className="text-sm font-bold text-white group-hover:text-gold transition-colors">{mod.title}</span>
                    </div>
                    <span className="material-icons text-gray-600 text-sm">{mod.icon}</span>
                 </div>
               ))}
            </div>
          </div>
        </div>

        {/* Footer Rollout */}
        <div className="flex flex-col md:flex-row justify-center items-center gap-12 border-t border-brand-border/20 pt-12 opacity-60">
           {['Blueprint', 'Model', 'Automate', 'Deploy'].map((step, i) => (
             <div key={step} className="flex items-center gap-4">
                <span className="text-xs font-mono text-gray-500">{i + 1}</span>
                <span className="text-sm font-bold text-white uppercase tracking-widest">{step}</span>
                {i < 3 && <span className="material-icons text-gray-700">arrow_forward</span>}
             </div>
           ))}
        </div>
      </div>
    </div>
  );
};

export default Architecture;
