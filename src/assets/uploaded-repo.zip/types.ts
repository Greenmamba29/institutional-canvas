
export type Page = 'home' | 'dashboard' | 'marketplace' | 'auctions' | 'intelligence' | 'trust' | 'resources' | 'about' | 'contact';

export enum VerificationTier {
  GOLD = 'Gold',
  SILVER = 'Silver',
  STANDARD = 'Standard'
}

export enum MaterialType {
  CARBONATE = 'Lithium Carbonate',
  HYDROXIDE = 'Lithium Hydroxide',
  CHLORIDE = 'Lithium Chloride',
  SPODUMENE = 'Spodumene'
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'supplier' | 'buyer';
  companyId: string;
  avatarUrl?: string;
}

export interface SupplierProfile {
  id: string;
  name: string;
  region: string;
  totalSalesYTD: number;
  verificationTier: VerificationTier;
  trustScore: number; // 0-100
  purityRating: number; // e.g., 99.9
  capacityMT: number;
  responseRate: string; // e.g., "4.2 hours"
  logoUrl: string;
  lastAuditDate: string;
}

export interface MaterialListing {
  id: string;
  supplierId: string;
  type: MaterialType;
  purity: number;
  quantityMT: number;
  pricePerMT: number;
  origin: string;
  status: 'available' | 'reserved' | 'sold';
}

export interface RFQ {
  id: string;
  buyerId: string;
  materialType: MaterialType;
  quantityRequiredMT: number;
  targetPurity: number;
  deliveryDate: string;
  status: 'open' | 'active' | 'closed' | 'awarded';
  createdAt: string;
}

export interface Auction {
  id: string;
  lotNumber: string;
  materialType: MaterialType;
  origin: string;
  quantityMT: number;
  startingBid: number;
  currentBid: number;
  reservePrice: number;
  timeLeft: string; // ISO string or relative time
  status: 'active' | 'ended' | 'scheduled';
}

export interface Order {
  id: string;
  transactionId: string;
  buyerId: string;
  supplierId: string;
  materialType: MaterialType;
  quantityMT: number;
  totalValue: number;
  status: 'escrow' | 'shipped' | 'delivered' | 'settled';
  createdAt: string;
}

export interface DashboardMetrics {
  gmvYTD: number;
  totalTransactions: number;
  activeEscrowValue: number;
  verifiedSuppliersCount: number;
  verifiedBuyersCount: number;
  averageSourcingTime: string;
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  userId: string;
  action: string;
  details: string;
  ipAddress?: string;
}
