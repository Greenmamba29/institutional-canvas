
import React, { useState } from 'react';
import Navbar from './Navbar';
import Sidebar from './Sidebar';
import { cn } from '../../utils';

interface AppLayoutProps {
  children: React.ReactNode;
  sidebar?: React.ReactNode;
  headerTitle?: string;
  headerBreadcrumbs?: { label: string; active?: boolean }[];
  tabs?: string[];
}

const AppLayout: React.FC<AppLayoutProps> = ({ 
  children, 
  sidebar,
  headerTitle = "Institutional Trading Console",
  headerBreadcrumbs = [
    { label: "Platform" },
    { label: "Trading Desk" },
    { label: "Overview", active: true }
  ],
  tabs = ['Dashboard', 'Auction Listings', 'Performance']
}) => {
  const [activeTab, setActiveTab] = useState(tabs[0]);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-brand-navy selection:bg-gold/30 selection:text-white flex flex-col overflow-hidden">
      <Navbar />
      
      {/* Mobile Sidebar Toggle */}
      <div className="lg:hidden fixed bottom-6 right-6 z-[60]">
        <button 
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="w-14 h-14 bg-gold rounded-full flex items-center justify-center shadow-2xl text-brand-navy"
        >
          <span className="material-icons">{mobileMenuOpen ? 'close' : 'menu'}</span>
        </button>
      </div>

      <div className="flex flex-1 overflow-hidden">
        {/* Sidebar - Fixed on desktop */}
        <div className={cn(
          "lg:block flex-shrink-0 relative z-40",
          mobileMenuOpen ? "block fixed inset-0 bg-brand-navy/90 backdrop-blur-xl" : "hidden"
        )}>
           {sidebar || <Sidebar />}
        </div>

        {/* Main Content Area - Single scroll container for the entire content view */}
        <main className="flex-1 lg:ml-[260px] pt-16 h-screen overflow-y-auto flex flex-col relative custom-scrollbar bg-brand-navy">
          
          {/* Sub-Header - Integrated into the scroll flow, not fixed or sticky */}
          <div className="w-full bg-brand-navy/50 px-8 pt-10 pb-2 border-b border-brand-border">
            <div className="max-w-7xl mx-auto">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 mb-8">
                <div>
                  <nav className="flex items-center gap-2 text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-2">
                    {headerBreadcrumbs.map((crumb, i) => (
                      <React.Fragment key={crumb.label}>
                        <span className={crumb.active ? "text-white" : "text-gray-400"}>{crumb.label}</span>
                        {i < headerBreadcrumbs.length - 1 && (
                          <span className="material-icons text-[10px] text-gray-600">chevron_right</span>
                        )}
                      </React.Fragment>
                    ))}
                  </nav>
                  <h1 className="text-4xl font-display font-bold text-white tracking-tight">{headerTitle}</h1>
                </div>
                
                <div className="flex items-center gap-2">
                  <div className="px-4 py-2 rounded-full border border-brand-border bg-white/5 flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-success"></span>
                    <span className="text-[10px] font-black text-white uppercase tracking-tighter">Live Market Status: Normal</span>
                  </div>
                </div>
              </div>

              {/* Tabs Section */}
              <div className="flex gap-12">
                {tabs.map(tab => (
                  <button
                    key={tab}
                    onClick={() => setActiveTab(tab)}
                    className={cn(
                      "pb-4 text-[11px] font-bold uppercase tracking-[0.2em] transition-all relative",
                      activeTab === tab 
                        ? "text-gold" 
                        : "text-gray-500 hover:text-gray-300"
                    )}
                  >
                    {tab}
                    {activeTab === tab && (
                      <div className="absolute bottom-0 left-0 right-0 h-[3px] bg-gold rounded-full shadow-[0_0_15px_rgba(212,168,83,0.5)]"></div>
                    )}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Body Content */}
          <div className="p-8 flex-1">
            <div className="max-w-7xl mx-auto animate-fade-in">
              {children}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
};

export default AppLayout;
