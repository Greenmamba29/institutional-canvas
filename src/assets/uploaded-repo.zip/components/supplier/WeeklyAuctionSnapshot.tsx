import React from 'react';
import GlobeVisualization from '../ui/GlobeVisualization';
// Added missing import for 'cn' utility
import { cn } from '../../utils';

const WeeklyAuctionSnapshot: React.FC = () => {
  return (
    <div className="glass rounded-2xl border border-brand-border/40 overflow-hidden relative group">
      {/* Background Effects */}
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_50%_0%,_#1A2D42_0%,_transparent_70%)] opacity-50"></div>
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-teal/5 to-transparent"></div>
      
      <div className="relative z-10 p-8">
        {/* Header */}
        <div className="flex justify-between items-center mb-10">
          <div>
            <h3 className="text-xl font-display font-bold text-white tracking-tight">Weekly Auction Snapshot</h3>
            <p className="text-[10px] text-gray-500 font-bold uppercase tracking-widest mt-1">Global Institutional Participation</p>
          </div>
          <div className="flex gap-4">
            <button className="material-icons text-gray-500 hover:text-white transition-colors text-lg">remove</button>
            <button className="material-icons text-gray-500 hover:text-white transition-colors text-lg">open_in_full</button>
            <button className="material-icons text-gray-500 hover:text-white transition-colors text-lg">settings</button>
          </div>
        </div>

        {/* Metrics and Visualization Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Metrics Column */}
          <div className="lg:col-span-3 space-y-10">
            <div>
              <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-1">Total Bids</p>
              <h4 className="text-4xl font-mono font-bold text-gold">$475K</h4>
              <p className="text-[9px] text-success font-black uppercase mt-1">+12.4% vs Last Event</p>
            </div>
            
            <div>
              <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-1">Active Lots</p>
              <div className="flex items-baseline gap-2">
                <h4 className="text-3xl font-mono font-bold text-white">15</h4>
                <span className="text-[10px] text-gray-400 font-bold uppercase">Carbonate & Hydroxide</span>
              </div>
            </div>

            <div>
              <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-1">Verified Bidders</p>
              <div className="flex items-center gap-2">
                <h4 className="text-3xl font-mono font-bold text-teal">21</h4>
                <div className="flex -space-x-2">
                  {[1, 2, 3].map(i => (
                    <div key={i} className="w-6 h-6 rounded-full border border-brand-navy bg-brand-panel overflow-hidden">
                      <img src={`https://i.pravatar.cc/100?u=bidder${i}`} className="w-full h-full object-cover grayscale" />
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Globe Column */}
          <div className="lg:col-span-7 relative h-[350px]">
            <GlobeVisualization />
          </div>

          {/* Scale Column */}
          <div className="lg:col-span-2 flex flex-col justify-between h-[300px] border-l border-brand-border/20 pl-6 py-4">
            {[
              { val: '53m', color: 'text-gold' },
              { val: '20m', color: 'text-white' },
              { val: '12m', color: 'text-white' },
              { val: '1.5m', color: 'text-gray-600' }
            ].map((scale, i) => (
              <div key={i} className="flex items-center gap-3">
                <div className="w-2 h-[1px] bg-brand-border/40"></div>
                <span className={cn("text-[11px] font-mono font-bold", scale.color)}>{scale.val}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default WeeklyAuctionSnapshot;