
import React from 'react';
import { cn, formatCurrency } from '../../utils';
import VerificationBadge from '../ui/VerificationBadge';

interface AuctionEntry {
  id: string;
  flag?: string;
  company: string;
  tier: 'gold' | 'silver' | 'standard';
  quantity: string;
  product: string;
  pricingInfo: string;
  unitPrice: number;
}

const entries: AuctionEntry[] = [
  {
    id: '1',
    flag: '🇨🇱',
    company: 'Kobalt Resources',
    tier: 'gold',
    quantity: '60 MT',
    product: 'Lithium Hydroxide',
    pricingInfo: 'Prcts: 1f., 3.04',
    unitPrice: 66500,
  },
  {
    id: '2',
    company: 'Solarcell Manufacturing',
    tier: 'gold',
    quantity: '160 MT',
    product: 'Spodumene',
    pricingInfo: 'Bulk Settlement',
    unitPrice: 6750,
  },
  {
    id: '3',
    flag: '🇨🇳',
    company: 'Yushen Metalics',
    tier: 'standard',
    quantity: '80 MT',
    product: 'Lithium Carbonate',
    pricingInfo: 'Spot Pricing',
    unitPrice: 51000,
  }
];

const UpcomingAuctions: React.FC = () => {
  return (
    <div className="glass rounded-2xl border border-brand-border/40 flex flex-col h-full overflow-hidden">
      <div className="p-6 border-b border-brand-border/20 flex justify-between items-center">
        <h3 className="text-xs font-black text-white uppercase tracking-[0.2em]">Upcoming Auctions</h3>
        <button className="text-[10px] font-bold text-gray-500 hover:text-white transition-colors uppercase">See Calendar</button>
      </div>

      <div className="flex-1 overflow-y-auto p-4 space-y-3 custom-scrollbar">
        {entries.map((auction) => (
          <div key={auction.id} className="p-4 rounded-xl bg-white/[0.02] border border-brand-border/20 hover:border-gold/30 transition-all cursor-pointer group">
            <div className="flex justify-between items-start mb-3">
              <div className="flex items-center gap-3">
                {auction.flag && <span className="text-lg">{auction.flag}</span>}
                <h4 className="text-xs font-bold text-white group-hover:text-gold transition-colors">{auction.company}</h4>
              </div>
              <VerificationBadge tier={auction.tier} />
            </div>

            <div className="flex justify-between items-end">
              <div>
                <p className="text-sm font-mono font-bold text-white">{auction.quantity}</p>
                <p className="text-[10px] text-gray-500 font-medium">{auction.product}</p>
              </div>
              <div className="text-right">
                <p className="text-[9px] text-gray-600 font-bold uppercase mb-0.5">{auction.pricingInfo}</p>
                <p className="text-xs font-mono font-bold text-gold">@{formatCurrency(auction.unitPrice)}/MT</p>
              </div>
            </div>
          </div>
        ))}
      </div>
      
      <div className="p-4 bg-brand-navy/30 border-t border-brand-border/20">
        <button className="w-full py-3 rounded-lg border border-brand-border/40 text-[10px] font-black text-gray-500 hover:text-white uppercase tracking-widest transition-all">
          Register for Next Lot
        </button>
      </div>
    </div>
  );
};

export default UpcomingAuctions;
