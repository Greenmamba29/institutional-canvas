
import React from 'react';
import { cn } from '../../utils';

export type BadgeVariant = 'gold' | 'silver' | 'standard' | 'success' | 'warning' | 'error' | 'teal';

interface BadgeProps {
  variant: BadgeVariant;
  children: React.ReactNode;
  icon?: string;
  className?: string;
}

const Badge: React.FC<BadgeProps> = ({ variant, children, icon, className }) => {
  const variants = {
    gold: "bg-gold/10 text-gold border-gold/30",
    silver: "bg-gray-400/10 text-gray-300 border-gray-400/30",
    standard: "bg-gray-600/10 text-gray-500 border-gray-600/30",
    success: "bg-success/10 text-success border-success/30",
    warning: "bg-warning/10 text-warning border-warning/30",
    error: "bg-error/10 text-error border-error/30",
    teal: "bg-teal/10 text-teal border-teal/30",
  };

  return (
    <span className={cn(
      "inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-black uppercase tracking-tighter border",
      variants[variant],
      className
    )}>
      {icon && <span className="material-icons text-[12px]">{icon}</span>}
      {children}
    </span>
  );
};

export default Badge;
