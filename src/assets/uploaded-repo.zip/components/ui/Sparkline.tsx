
import React from 'react';

interface SparklineProps {
  data: number[];
  color?: string;
  width?: number | string;
  height?: number | string;
}

const Sparkline: React.FC<SparklineProps> = ({ 
  data, 
  color = "#D4A853", 
  width = "100%", 
  height = 40 
}) => {
  if (!data || data.length < 2) return null;

  const min = Math.min(...data);
  const max = Math.max(...data);
  const range = max - min || 1;
  
  const points = data.map((val, i) => {
    const x = (i / (data.length - 1)) * 100;
    const y = 100 - ((val - min) / range) * 100;
    return `${x},${y}`;
  }).join(' ');

  return (
    <div style={{ width, height }}>
      <svg viewBox="0 0 100 100" className="w-full h-full overflow-visible" preserveAspectRatio="none">
        <polyline
          fill="none"
          stroke={color}
          strokeWidth="4"
          strokeLinecap="round"
          strokeLinejoin="round"
          points={points}
          className="drop-shadow-[0_0_2px_rgba(212,168,83,0.3)]"
        />
      </svg>
    </div>
  );
};

export default Sparkline;
