
import React, { useState } from 'react';

const Marketplace: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');

  return (
    <div className="pt-24 lg:ml-64 p-6 lg:p-10 min-h-screen">
      <div className="max-w-7xl mx-auto">
        <header className="mb-12">
          <div className="flex items-center gap-2 mb-4">
            <span className="text-[10px] font-bold text-gold border border-gold/30 px-2 py-0.5 rounded uppercase">Directory</span>
            <span className="text-[10px] text-gray-600 font-bold uppercase tracking-widest">Global Network Verified</span>
          </div>
          <h1 className="text-5xl font-display font-bold text-white mb-6">Tier-1 Supplier <span className="text-gold-gradient italic">Directory</span></h1>
          <p className="text-gray-400 max-w-2xl font-light text-lg">Direct access to institutional-grade lithium sources. Verified provenance, authenticated capacity, and real-time availability.</p>
        </header>

        <div className="flex flex-col lg:flex-row gap-10">
          {/* Filters */}
          <aside className="w-full lg:w-72 flex-shrink-0">
             <div className="glass p-8 rounded-xl sticky top-24">
                <h3 className="font-bold text-white mb-8 flex items-center gap-2">
                   <span className="material-icons text-gold text-lg">tune</span> Filters
                </h3>
                
                <div className="space-y-10">
                   <div>
                      <h4 className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-6">Compound Type</h4>
                      <div className="space-y-4">
                         {['Li Carbonate', 'Li Hydroxide', 'Li Chloride', 'Spodumene'].map(t => (
                           <label key={t} className="flex items-center gap-3 cursor-pointer group">
                              <input type="checkbox" className="w-4 h-4 rounded border-brand-border bg-brand-navy text-gold focus:ring-gold" />
                              <span className="text-sm text-gray-400 group-hover:text-white transition-colors">{t}</span>
                           </label>
                         ))}
                      </div>
                   </div>

                   <div>
                      <h4 className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-6">Verification Tier</h4>
                      <div className="space-y-4">
                         {[
                           { name: 'Gold', color: 'text-gold' },
                           { name: 'Silver', color: 'text-gray-300' },
                           { name: 'Standard', color: 'text-gray-500' }
                         ].map(tier => (
                           <label key={tier.name} className="flex items-center gap-3 cursor-pointer group">
                              <input type="checkbox" className="w-4 h-4 rounded border-brand-border bg-brand-navy text-gold focus:ring-gold" />
                              <span className={`text-sm font-bold ${tier.color}`}>{tier.name} Verified</span>
                           </label>
                         ))}
                      </div>
                   </div>

                   <div>
                      <h4 className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-6">Origin Region</h4>
                      <div className="space-y-4">
                         {['Chile', 'Australia', 'Argentina', 'Canada', 'USA'].map(region => (
                           <label key={region} className="flex items-center gap-3 cursor-pointer group">
                              <input type="checkbox" className="w-4 h-4 rounded border-brand-border bg-brand-navy text-gold focus:ring-gold" />
                              <span className="text-sm text-gray-400 group-hover:text-white transition-colors">{region}</span>
                           </label>
                         ))}
                      </div>
                   </div>
                </div>

                <button className="w-full mt-10 py-3 bg-brand-navy border border-brand-border rounded text-xs font-bold text-gray-400 hover:text-white hover:border-gold transition-all uppercase tracking-widest">Reset All</button>
             </div>
          </aside>

          {/* List */}
          <div className="flex-1 space-y-6">
             <div className="glass p-4 rounded-xl mb-10 flex gap-4 items-center">
                <div className="relative flex-1">
                   <span className="material-icons absolute left-4 top-1/2 -translate-y-1/2 text-gray-500">search</span>
                   <input 
                     type="text" 
                     placeholder="Search by supplier name, chemistry spec, or location..." 
                     className="w-full pl-12 pr-4 py-3 bg-brand-navy border border-brand-border rounded-lg text-white focus:ring-gold focus:border-gold text-sm"
                     value={searchTerm}
                     onChange={(e) => setSearchTerm(e.target.value)}
                   />
                </div>
                <button className="bg-gold text-brand-navy font-bold px-8 py-3 rounded-lg shadow-lg uppercase tracking-widest text-xs">Search</button>
             </div>

             {[
               { name: 'LithiumCorp', tier: 'Gold', loc: 'Chile', purity: '99.9%', capacity: '1,200 MT/y', price: '$53,400', tags: ['Battery Grade', 'High Purity'] },
               { name: 'EverSource Minerals', tier: 'Gold', loc: 'Australia', purity: '99.5%', capacity: '4,500 MT/y', price: '$52,800', tags: ['Raw Spodumene', 'Contract Ready'] },
               { name: 'Metalistica', tier: 'Silver', loc: 'Argentina', purity: '98.2%', capacity: '800 MT/y', price: '$49,100', tags: ['Tech Grade', 'Low Chloride'] },
               { name: 'Santiago Lithium S.A.', tier: 'Silver', loc: 'Chile', purity: '99.0%', capacity: '2,100 MT/y', price: '$51,200', tags: ['Carbonate', 'Spot Only'] },
             ].map((supplier, i) => (
               <div key={i} className="glass p-1 rounded hover:border-gold/30 transition-all group overflow-hidden">
                  <div className="p-8 rounded-lg bg-white/[0.02]">
                     <div className="flex flex-col md:flex-row gap-10">
                        <div className="w-24 h-24 rounded-2xl bg-brand-navy border border-brand-border flex items-center justify-center p-4 relative flex-shrink-0 group-hover:border-gold/50 transition-colors">
                           <img src={`https://picsum.photos/seed/${supplier.name}/128/128`} className="w-full h-full object-contain opacity-60 group-hover:opacity-100 transition-all grayscale group-hover:grayscale-0" alt="logo" />
                           <div className={`absolute -bottom-2 -right-2 w-8 h-8 rounded-full border-2 border-brand-navy flex items-center justify-center ${supplier.tier === 'Gold' ? 'bg-gold' : 'bg-gray-400'}`}>
                              <span className="material-icons text-brand-navy text-sm font-black">{supplier.tier === 'Gold' ? 'verified' : 'check'}</span>
                           </div>
                        </div>
                        <div className="flex-1">
                           <div className="flex flex-col md:flex-row justify-between items-start gap-4 mb-6">
                              <div>
                                 <h3 className="text-2xl font-bold text-white group-hover:text-gold transition-colors">{supplier.name}</h3>
                                 <div className="flex items-center gap-3 text-xs text-gray-500 mt-2 uppercase tracking-widest font-bold">
                                    <span className="flex items-center gap-1"><span className="material-icons text-sm text-gold">location_on</span> {supplier.loc}</span>
                                    <span>•</span>
                                    <span className={`font-black ${supplier.tier === 'Gold' ? 'text-gold' : 'text-gray-400'}`}>{supplier.tier} Verified</span>
                                 </div>
                              </div>
                              <div className="text-right">
                                 <p className="text-2xl font-mono font-bold text-white">{supplier.price}<span className="text-xs text-gray-500 font-normal ml-1">/MT</span></p>
                                 <p className="text-[10px] text-success font-bold uppercase tracking-widest mt-1">Live Spot Price</p>
                              </div>
                           </div>
                           
                           <div className="grid grid-cols-2 md:grid-cols-4 gap-8 py-6 border-t border-brand-border">
                              <div>
                                 <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-1">Purity</p>
                                 <p className="text-sm font-mono font-bold text-white">{supplier.purity}</p>
                              </div>
                              <div>
                                 <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-1">Annual Cap.</p>
                                 <p className="text-sm font-mono font-bold text-white">{supplier.capacity}</p>
                              </div>
                              <div>
                                 <p className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-1">Response Rate</p>
                                 <p className="text-sm font-mono font-bold text-white">4.2 Hours</p>
                              </div>
                              <div className="flex flex-wrap gap-2 justify-end">
                                 {supplier.tags.map(tag => (
                                   <span key={tag} className="px-2 py-0.5 rounded border border-brand-border text-[9px] font-bold text-gray-400 uppercase tracking-tighter group-hover:border-gold/30">{tag}</span>
                                 ))}
                              </div>
                           </div>

                           <div className="mt-4 flex flex-col sm:flex-row gap-4 justify-end">
                              <button className="px-6 py-2 border border-brand-border rounded text-xs font-bold text-gray-400 hover:text-white hover:bg-white/5 transition-all uppercase tracking-widest">Download Compliance</button>
                              <button className="px-8 py-2 bg-gold text-brand-navy rounded font-bold hover:bg-gold-bright transition-all text-xs uppercase tracking-widest shadow-lg shadow-gold/20">Initiate RFQ</button>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
             ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Marketplace;
