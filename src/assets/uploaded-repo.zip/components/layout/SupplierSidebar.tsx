
import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { cn } from '../../utils';

interface NavItem {
  label: string;
  icon: string;
  path: string;
  badge?: string;
}

const SupplierSidebar: React.FC = () => {
  const location = useLocation();
  const isActive = (path: string) => location.pathname === path;

  const navItems: NavItem[] = [
    { label: 'Dashboard', icon: 'home', path: '/supplier/dashboard' },
    { label: 'RFQs', icon: 'description', path: '/rfqs', badge: '15' },
    { label: 'Auctions', icon: 'gavel', path: '/auctions', badge: '2' },
    { label: 'Orders', icon: 'shopping_cart', path: '/orders', badge: '3' },
    { label: 'Analytics', icon: 'analytics', path: '/analytics' },
    { label: 'Messages', icon: 'mail_outline', path: '/messages', badge: '3' },
    { label: 'Directory', icon: 'contacts', path: '/directory' },
    { label: 'Settings', icon: 'settings', path: '/settings' },
    { label: 'Help Center', icon: 'help_outline', path: '/help' },
  ];

  return (
    <aside className="fixed left-0 top-0 h-full w-[260px] glass border-r border-brand-border z-40 hidden lg:flex flex-col pt-16">
      {/* Supplier Profile Section */}
      <div className="p-6 pb-2 border-b border-brand-border/30">
        <div className="flex items-center gap-4 mb-4">
          <div className="w-12 h-12 rounded-lg bg-brand-panel border border-gold/30 overflow-hidden flex-shrink-0">
            <img src="https://picsum.photos/seed/lithiumcorp/100/100" alt="LithiumCorp" className="w-full h-full object-cover grayscale opacity-80" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-white">LithiumCorp</h3>
            <div className="flex items-center gap-1 mt-0.5">
              <span className="material-icons text-[10px] text-gold">star</span>
              <span className="text-[9px] font-black text-gold uppercase tracking-tighter">Gold Verified</span>
            </div>
          </div>
        </div>
        
        <div className="flex justify-between items-center mb-4">
          <span className="text-[10px] font-bold text-gray-500 uppercase tracking-widest">Total Sales</span>
          <span className="text-xs font-mono font-bold text-white">$3.75M</span>
        </div>

        <div className="h-px bg-brand-border/20 w-full mb-4"></div>

        <div className="flex items-center gap-3 mb-6">
          <div className="w-8 h-8 rounded-full border border-teal/30 p-0.5">
            <img src="https://i.pravatar.cc/150?u=diego" alt="Diego Santos" className="w-full h-full rounded-full grayscale" />
          </div>
          <div className="flex-1">
            <p className="text-[11px] font-bold text-white">Diego Santos</p>
            <p className="text-[9px] text-teal font-black uppercase tracking-tighter">1x Live RFQ • $47.3K</p>
          </div>
        </div>

        <button className="w-full py-2.5 border border-gold/40 rounded-lg text-[10px] font-black text-gold hover:bg-gold/10 transition-all uppercase tracking-[0.15em] flex items-center justify-center gap-2">
          List New Material <span className="material-icons text-xs">add</span>
        </button>
      </div>

      <nav className="flex-1 px-4 py-4 space-y-1 overflow-y-auto custom-scrollbar">
        {navItems.map((item) => (
          <Link
            key={item.label}
            to={item.path}
            className={cn(
              "flex items-center justify-between px-3 py-2 rounded-lg transition-all group relative",
              isActive(item.path)
                ? "text-white bg-gold/5 border-l-2 border-gold shadow-[inset_10px_0_15px_-10px_rgba(212,168,83,0.3)]"
                : "text-gray-400 hover:text-white hover:bg-white/5"
            )}
          >
            <div className="flex items-center gap-3">
              <span className={cn(
                "material-icons text-[20px]",
                isActive(item.path) ? "text-gold" : "text-gray-500 group-hover:text-gray-300"
              )}>
                {item.icon}
              </span>
              <span className="text-[13px] font-semibold tracking-wide">
                {item.label}
              </span>
            </div>
            {item.badge && (
              <span className={cn(
                "text-[9px] font-black px-1.5 py-0.5 rounded min-w-[18px] text-center bg-brand-panel border border-brand-border/40",
                isActive(item.path) ? "text-gold" : "text-gray-500"
              )}>
                {item.badge}
              </span>
            )}
          </Link>
        ))}
      </nav>
      
      <div className="p-4 border-t border-brand-border/20 text-center">
        <span className="text-[8px] font-bold text-gray-600 uppercase tracking-[0.2em]">Supplier Terminal v4.1</span>
      </div>
    </aside>
  );
};

export default SupplierSidebar;
