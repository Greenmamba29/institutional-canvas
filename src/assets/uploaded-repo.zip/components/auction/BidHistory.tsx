
import React, { useEffect, useRef } from 'react';
import { cn, formatCurrency, formatRelativeTime } from '../../utils';

export interface Bid {
  id: string;
  bidderName: string; // "Bidder #42" or "You"
  amount: number;
  timestamp: Date;
  isUser?: boolean;
}

interface BidHistoryProps {
  bids: Bid[];
  className?: string;
}

const BidHistory: React.FC<BidHistoryProps> = ({ bids, className }) => {
  const scrollRef = useRef<HTMLDivElement>(null);

  // Auto-scroll to bottom on new bids
  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [bids]);

  return (
    <div className={cn("glass rounded-xl border border-brand-border/40 flex flex-col h-full overflow-hidden", className)}>
      <div className="p-4 border-b border-brand-border/20 flex justify-between items-center bg-white/[0.02]">
        <h3 className="text-[10px] font-black text-white uppercase tracking-[0.2em] flex items-center gap-2">
          <span className="w-1.5 h-1.5 rounded-full bg-error animate-pulse"></span>
          Live Bid History
        </h3>
        <span className="text-[9px] font-bold text-gray-500 uppercase">{bids.length} Active Bids</span>
      </div>

      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-4 space-y-3 custom-scrollbar scroll-smooth"
      >
        {bids.length === 0 ? (
          <div className="h-full flex flex-col items-center justify-center opacity-30">
            <span className="material-icons text-4xl mb-2">history</span>
            <p className="text-[10px] font-bold uppercase tracking-widest">No bids yet</p>
          </div>
        ) : (
          bids.map((bid) => (
            <div 
              key={bid.id} 
              className={cn(
                "flex justify-between items-center p-2.5 rounded-lg border transition-all animate-fade-in",
                bid.isUser 
                  ? "bg-gold/10 border-gold/30 shadow-[0_0_15px_-5px_rgba(212,168,83,0.3)]" 
                  : "bg-white/[0.03] border-brand-border/20"
              )}
            >
              <div>
                <div className="flex items-center gap-2">
                  <span className={cn(
                    "text-[11px] font-bold",
                    bid.isUser ? "text-gold" : "text-white"
                  )}>
                    {bid.bidderName}
                  </span>
                  {bid.isUser && <span className="bg-gold text-brand-navy text-[8px] font-black px-1 rounded uppercase">You</span>}
                </div>
                <p className="text-[9px] text-gray-500 font-medium">
                  {formatRelativeTime(bid.timestamp)}
                </p>
              </div>
              <div className="text-right">
                <p className={cn(
                  "text-sm font-mono font-bold",
                  bid.isUser ? "text-gold" : "text-white"
                )}>
                  {formatCurrency(bid.amount)}
                </p>
                <div className="flex items-center justify-end gap-0.5 text-[8px] font-black text-success uppercase">
                  <span className="material-icons text-[10px]">north</span>
                  Verified
                </div>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default BidHistory;
