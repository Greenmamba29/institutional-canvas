
import React from 'react';

const GlobeVisualization: React.FC = () => {
  return (
    <div className="relative w-full h-full flex items-center justify-center overflow-hidden">
      {/* Background Glow */}
      <div className="absolute w-[300px] h-[300px] bg-teal/10 blur-[80px] rounded-full animate-pulse-slow"></div>
      
      <svg viewBox="0 0 400 400" className="w-full h-full max-w-[400px] relative z-10">
        {/* Globe Sphere */}
        <defs>
          <radialGradient id="globeGrad" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#1A2D42" />
            <stop offset="100%" stopColor="#0A1628" />
          </radialGradient>
          <filter id="glow">
            <feGaussianBlur stdDeviation="2.5" result="coloredBlur"/>
            <feMerge>
                <feMergeNode in="coloredBlur"/>
                <feMergeNode in="SourceGraphic"/>
            </feMerge>
          </filter>
        </defs>
        
        <circle cx="200" cy="200" r="140" fill="url(#globeGrad)" stroke="#2D4A6F" strokeWidth="0.5" />
        
        {/* Lat/Long Grid Lines */}
        <g stroke="#2D4A6F" strokeWidth="0.2" fill="none">
          <ellipse cx="200" cy="200" rx="140" ry="40" />
          <ellipse cx="200" cy="200" rx="140" ry="80" />
          <ellipse cx="200" cy="200" rx="40" ry="140" />
          <ellipse cx="200" cy="200" rx="80" ry="140" />
          <line x1="60" y1="200" x2="340" y2="200" />
          <line x1="200" y1="60" x2="200" y2="340" />
        </g>

        {/* Network Arcs */}
        <g stroke="rgba(14, 165, 233, 0.4)" strokeWidth="1" fill="none" className="animate-pulse">
          <path d="M120 150 Q 200 80 280 150" strokeDasharray="5,5" />
          <path d="M100 220 Q 200 300 300 220" strokeDasharray="3,3" />
          <path d="M150 120 Q 250 150 250 280" strokeDasharray="4,4" />
        </g>

        {/* Active Nodes */}
        <g filter="url(#glow)">
          {/* Americas */}
          <circle cx="120" cy="150" r="4" fill="#0EA5E9" className="animate-ping" style={{ animationDuration: '3s' }} />
          <circle cx="120" cy="150" r="3" fill="#0EA5E9" />
          
          {/* Europe */}
          <circle cx="210" cy="130" r="4" fill="#D4A853" className="animate-ping" style={{ animationDuration: '4s' }} />
          <circle cx="210" cy="130" r="3" fill="#D4A853" />
          
          {/* Asia */}
          <circle cx="280" cy="160" r="4" fill="#0EA5E9" className="animate-ping" style={{ animationDuration: '2.5s' }} />
          <circle cx="280" cy="160" r="3" fill="#0EA5E9" />
          
          {/* Australia */}
          <circle cx="290" cy="260" r="4" fill="#D4A853" className="animate-ping" style={{ animationDuration: '3.5s' }} />
          <circle cx="290" cy="260" r="3" fill="#D4A853" />
        </g>
      </svg>
    </div>
  );
};

export default GlobeVisualization;
