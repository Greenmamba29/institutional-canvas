
import React from 'react';
import { SupplierProfile } from '../../types';
import VerificationBadge, { VerificationTier } from '../ui/VerificationBadge';
import { formatCurrency, cn } from '../../utils';

interface SupplierDetailDrawerProps {
  supplier: SupplierProfile | null;
  onClose: () => void;
}

const SupplierDetailDrawer: React.FC<SupplierDetailDrawerProps> = ({ supplier, onClose }) => {
  if (!supplier) return null;

  return (
    <>
      <div 
        className="fixed inset-0 bg-brand-navy/60 backdrop-blur-sm z-[100] transition-opacity animate-fade-in"
        onClick={onClose}
      />
      <div className="fixed top-0 right-0 h-full w-full max-w-2xl bg-brand-navy border-l border-brand-border z-[101] shadow-2xl flex flex-col overflow-hidden animate-slide-in-right">
        {/* Header */}
        <div className="p-8 border-b border-brand-border/40 relative">
          <button 
            onClick={onClose}
            className="absolute top-8 right-8 text-gray-500 hover:text-white transition-colors"
          >
            <span className="material-icons">close</span>
          </button>

          <div className="flex gap-6 items-start">
            <div className="w-24 h-24 rounded-2xl bg-brand-panel border border-brand-border/40 p-4 shadow-xl">
              <img src={supplier.logoUrl} className="w-full h-full object-contain" />
            </div>
            <div className="pt-2">
              <div className="flex items-center gap-3 mb-2">
                <h2 className="text-3xl font-display font-bold text-white">{supplier.name}</h2>
                <VerificationBadge tier={supplier.verificationTier.toLowerCase() as VerificationTier} />
              </div>
              <p className="text-xs text-gray-500 font-bold uppercase tracking-[0.2em] flex items-center gap-2">
                <span className="material-icons text-sm text-gold">location_on</span>
                {supplier.region} Operations Terminal
              </p>
            </div>
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-8 space-y-12 custom-scrollbar">
          {/* High-level Metrics */}
          <div className="grid grid-cols-3 gap-6">
            <div className="p-5 rounded-2xl bg-white/[0.02] border border-brand-border/20 text-center">
              <p className="text-[9px] font-bold text-gray-500 uppercase tracking-widest mb-1">Total Sales</p>
              <p className="text-lg font-mono font-bold text-white">{formatCurrency(supplier.totalSalesYTD)}</p>
            </div>
            <div className="p-5 rounded-2xl bg-white/[0.02] border border-brand-border/20 text-center">
              <p className="text-[9px] font-bold text-gray-500 uppercase tracking-widest mb-1">Trust Score</p>
              <p className="text-lg font-mono font-bold text-gold">{supplier.trustScore}</p>
            </div>
            <div className="p-5 rounded-2xl bg-white/[0.02] border border-brand-border/20 text-center">
              <p className="text-[9px] font-bold text-gray-500 uppercase tracking-widest mb-1">Audit Date</p>
              <p className="text-lg font-mono font-bold text-teal">{supplier.lastAuditDate.split('-')[1]}/{supplier.lastAuditDate.split('-')[0].slice(2)}</p>
            </div>
          </div>

          {/* Detailed Info */}
          <section>
            <h4 className="text-[10px] font-black text-white uppercase tracking-[0.2em] mb-6 border-b border-brand-border/20 pb-2">Operational Specifications</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-8">
              {[
                { label: 'Primary Material', val: 'Lithium Hydroxide' },
                { label: 'Purity Benchmark', val: `${supplier.purityRating}% Battery Grade` },
                { label: 'Annual Capacity', val: `${supplier.capacityMT.toLocaleString()} MT` },
                { label: 'Logistics Range', val: 'Global (EXW, FOB, CIF)' },
                { label: 'Response Target', val: supplier.responseRate },
                { label: 'Extraction Method', val: 'Solar Brine Concentration' },
              ].map(item => (
                <div key={item.label} className="flex justify-between items-center border-b border-brand-border/10 pb-2">
                  <span className="text-[11px] font-bold text-gray-500 uppercase">{item.label}</span>
                  <span className="text-[12px] font-bold text-white">{item.val}</span>
                </div>
              ))}
            </div>
          </section>

          {/* Certifications */}
          <section>
            <h4 className="text-[10px] font-black text-white uppercase tracking-[0.2em] mb-6 border-b border-brand-border/20 pb-2">Compliance & Verification</h4>
            <div className="grid grid-cols-2 gap-4">
               {['ISO 9001:2015', 'ISO 14001:2015', 'RMI RMAP Audited', 'LME Registered'].map(cert => (
                 <div key={cert} className="flex items-center gap-3 p-3 rounded-lg bg-teal/5 border border-teal/20">
                    <span className="material-icons text-teal text-sm">verified</span>
                    <span className="text-[11px] font-bold text-gray-300">{cert}</span>
                 </div>
               ))}
            </div>
          </section>
        </div>

        {/* Footer Actions */}
        <div className="p-8 border-t border-brand-border/40 bg-brand-navy/80 backdrop-blur-md flex gap-4">
          <button className="flex-1 py-4 bg-gold text-brand-navy font-black text-xs uppercase tracking-widest rounded-xl hover:bg-gold-bright transition-all shadow-xl shadow-gold/20 flex items-center justify-center gap-2">
            Initiate Institutional RFQ
            <span className="material-icons text-base">send</span>
          </button>
          <button className="flex-1 py-4 border border-brand-border text-white font-black text-xs uppercase tracking-widest rounded-xl hover:bg-white/5 transition-all">
            Contact Desk
          </button>
        </div>
      </div>
    </>
  );
};

export default SupplierDetailDrawer;
